(function() {
  'use strict';

  /**
   * Siebel PDI Automator Pro — Page-Context Automation Engine
   * ──────────────────────────────────────────────────────────
   * This script is injected into the Oracle Siebel CRM page context via
   * content.js to access the SiebelApp JavaScript API (window.SiebelApp),
   * which is only available in the page's own execution context.
   *
   * It automates Pre-Delivery Inspection (PDI) workflows by:
   *  1. Searching VINs via the Siebel search pane
   *  2. Navigating to the PDI detail tab
   *  3. Selecting technician, setting status, clearing battery, saving & submitting
   *
   * NO remote code is loaded. NO user data is exfiltrated.
   * All communication is via window.postMessage to the content script.
   */

  // ═══════════════════════════════════════════════════════════════
  // INSTANCE GUARD — Prevent stale VMs from processing messages
  // Only the LATEST injected script should handle automation.
  // ═══════════════════════════════════════════════════════════════
  const INSTANCE_ID = Date.now() + '_' + Math.random().toString(36).slice(2);
  window.__SIEBEL_AUTOMATOR_INSTANCE__ = INSTANCE_ID;
  console.log('[Siebel Automator Pro] High-Speed Engine initialized. Instance:', INSTANCE_ID);

  // ═══════════════════════════════════════════════════════════════
  // NATIVE BROWSER DIALOG INTERCEPTION
  // Oracle Siebel CRM fires blocking confirm()/alert() dialogs during
  // record operations (save, submit, navigation). These freeze the
  // automation thread. We intercept them to auto-accept and log.
  // The originals are preserved so they can be restored if needed.
  // ═══════════════════════════════════════════════════════════════
  const _nativeConfirm = window.confirm;
  const _nativeAlert = window.alert;

  window.confirm = function(message) {
    console.warn('[Siebel Automator Pro] Intercepted window.confirm:', message);
    logMessage(`[Auto-Confirm] Handled browser dialog: "${message}"`, 'info');
    return true;
  };

  window.alert = function(message) {
    console.warn('[Siebel Automator Pro] Intercepted window.alert:', message);
    logMessage(`[Auto-Alert] Handled browser alert: "${message}"`, 'info');
    return true;
  };

  try {
    if (window.SiebelApp && window.SiebelApp.S_App) {
      if (typeof window.SiebelApp.S_App.ShowConfirmDialog === 'function') {
        window.SiebelApp.S_App.ShowConfirmDialog = function(msg, cb) {
          console.warn('[Siebel Automator Pro] Intercepted SiebelApp.ShowConfirmDialog:', msg);
          if (typeof cb === 'function') cb(true);
        };
      }
    }
  } catch (e) { /* ignore — SiebelApp may not be loaded yet */ }

  // Default speed configuration
  let speedConfig = {
    profile: 'balanced', // 'turbo', 'balanced', 'safe'
    microCheck: 25,      // ms interval for polling conditions
    settleDelay: 80,     // ms settle delay after DOM operations
    actionDelay: 60,     // ms delay between micro-actions
    readyTimeout: 30000  // ms max wait for page readiness
  };

  function updateSpeedConfig(profile) {
    if (profile === 'turbo') {
      speedConfig.profile = 'turbo';
      speedConfig.microCheck = 15;
      speedConfig.settleDelay = 30;
      speedConfig.actionDelay = 30;
      speedConfig.readyTimeout = 25000;
    } else if (profile === 'safe') {
      speedConfig.profile = 'safe';
      speedConfig.microCheck = 50;
      speedConfig.settleDelay = 200;
      speedConfig.actionDelay = 150;
      speedConfig.readyTimeout = 40000;
    } else {
      speedConfig.profile = 'balanced';
      speedConfig.microCheck = 25;
      speedConfig.settleDelay = 80;
      speedConfig.actionDelay = 60;
      speedConfig.readyTimeout = 30000;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // EVENT LISTENERS & MESSAGE DISPATCHER
  // ═══════════════════════════════════════════════════════════════
  window.addEventListener('message', async (event) => {
    if (event.source !== window || !event.data) return;

    if (event.data.type === 'SIEBEL_PROCESS_ROW') {
      if (window.__SIEBEL_AUTOMATOR_INSTANCE__ !== INSTANCE_ID) {
        console.warn('[Siebel Automator Pro] Stale instance received message, ignoring.');
        return;
      }

      const payload = event.data.payload;
      if (payload.speedProfile) {
        updateSpeedConfig(payload.speedProfile);
      }

      const startTime = Date.now();
      try {
        await processRow(payload);
        const durationSec = Math.round((Date.now() - startTime) / 1000);
        sendResponse(payload.vin, 'Success', '', durationSec);
      } catch (err) {
        console.error('[Siebel Automator Pro] Process row error for VIN:', payload.vin, err);
        const alertMsg = await checkAndDismissAlerts();
        const finalError = alertMsg ? `${err.message} (Alert: ${alertMsg})` : err.message;
        const durationSec = Math.round((Date.now() - startTime) / 1000);
        sendResponse(payload.vin, 'Error', finalError, durationSec);
      }
    }
  });

  function logMessage(message, level = 'info') {
    window.postMessage({ type: 'SIEBEL_LOG_MESSAGE', message, level }, '*');
  }

  function sendResponse(vin, status, errorDetails = '', duration = 0) {
    window.postMessage({
      type: 'PDI_RECORD_PROCESSED',
      payload: { vin, status, errorDetails, duration }
    }, '*');
  }

  // ═══════════════════════════════════════════════════════════════
  // REACTIVE UTILITIES
  // ═══════════════════════════════════════════════════════════════

  function microDelay(ms = speedConfig.actionDelay) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function isVisible(el) {
    if (!el) return false;
    if (!el.offsetParent && el.offsetWidth === 0 && el.offsetHeight === 0) {
      const s = window.getComputedStyle(el);
      if (s.display === 'none' || s.visibility === 'hidden') return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function waitForElement(selector, parent = document, timeoutMs = 7000) {
    return new Promise((resolve) => {
      const existing = parent.querySelector(selector);
      if (existing && isVisible(existing)) {
        return resolve(existing);
      }

      const start = Date.now();
      let observer = null;
      let intervalId = null;
      let resolved = false;

      const cleanup = () => {
        if (resolved) return;
        resolved = true;
        if (observer) observer.disconnect();
        if (intervalId) clearInterval(intervalId);
      };

      const check = () => {
        if (resolved) return;
        const el = parent.querySelector(selector);
        if (el && isVisible(el)) {
          cleanup();
          return resolve(el);
        }
        if (Date.now() - start > timeoutMs) {
          cleanup();
          return resolve(null);
        }
      };

      if (window.MutationObserver) {
        observer = new MutationObserver(() => check());
        observer.observe(parent === document ? document.body || document.documentElement : parent, {
          childList: true,
          subtree: true,
          attributes: true
        });
      }

      intervalId = setInterval(() => check(), speedConfig.microCheck);
    });
  }

  function waitForCondition(predicate, timeoutMs = 7000) {
    return new Promise((resolve) => {
      if (predicate()) return resolve(true);

      const start = Date.now();
      const intervalId = setInterval(() => {
        try {
          if (predicate()) {
            clearInterval(intervalId);
            return resolve(true);
          }
        } catch (e) { /* ignore */ }

        if (Date.now() - start > timeoutMs) {
          clearInterval(intervalId);
          return resolve(false);
        }
      }, speedConfig.microCheck);
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // SYSTEM READINESS & ALERT DETECTION
  // ═══════════════════════════════════════════════════════════════

  function isSiebelBusy() {
    try {
      if (typeof SiebelApp !== 'undefined' && SiebelApp.S_App) {
        if (typeof SiebelApp.S_App.IsBusy === 'function' && SiebelApp.S_App.IsBusy()) {
          return true;
        }
      }
    } catch (e) { /* ignore */ }

    const busySelectors = [
      '.siebel-busy',
      '.siebui-busy',
      '.siebui-wait',
      '#s_swepi_loading',
      '.ui-widget-overlay.jqgrid-overlay',
      '.blockUI.blockOverlay'
    ];

    for (const sel of busySelectors) {
      const el = document.querySelector(sel);
      if (el && isVisible(el)) return true;
    }

    return false;
  }

  async function waitPageReady(timeoutMs = speedConfig.readyTimeout) {
    const start = Date.now();

    while (Date.now() - start < timeoutMs) {
      try {
        const alertMsg = await checkAndDismissAlerts();
        if (alertMsg) {
          logMessage(`[Siebel Automator Pro] Handled alert: "${alertMsg}"`, 'info');
          if (/error|failed|invalid|not allowed/i.test(alertMsg)) {
            throw new Error(`Siebel Alert: ${alertMsg}`);
          }
        }
      } catch (e) {
        if (e.message && e.message.startsWith('Siebel Alert:')) throw e;
      }

      if (typeof SiebelApp === 'undefined' || !SiebelApp.S_App) {
        await microDelay(speedConfig.microCheck * 2);
        continue;
      }

      if (!isSiebelBusy()) {
        if (speedConfig.settleDelay > 0) {
          await microDelay(speedConfig.settleDelay);
        }
        return true;
      }

      await microDelay(speedConfig.microCheck);
    }

    throw new Error('Timeout waiting for Siebel CRM to finish processing.');
  }

  // Safe alert checker: NEVER dismisses Picklist dialogs containing jqGrid tables
  async function checkAndDismissAlerts() {
    const dialogs = document.querySelectorAll(
      '.ui-dialog, .siebui-popup-dialog, .siebui-error-dialog'
    );
    for (const dialog of dialogs) {
      if (!isVisible(dialog)) continue;

      // CRITICAL: NEVER click OK on a Picklist dialog (which has a jqGrid or pick applet container)
      if (dialog.querySelector('table.ui-jqgrid-btable, .ui-jqgrid-view, [id*="Pick"], [id*="pick"], [class*="AppletStylePopup"]')) {
        continue;
      }

      const isErrorAlert = dialog.querySelector('.siebui-popup-msg, .siebui-error-msg, .siebui-error-dialog') ||
                           dialog.classList.contains('siebui-error-dialog') ||
                           /error|warning|invalid|cannot|required|alert|discard/i.test(dialog.textContent);

      if (!isErrorAlert) continue;

      const msgEl = dialog.querySelector('.siebui-popup-msg, .siebui-error-msg, .ui-dialog-content');
      const msg = msgEl ? msgEl.textContent.trim() : 'Unknown alert dialog';

      const closeBtn = dialog.querySelector(
        'button[data-display="OK"], button[title*="OK"], button[aria-label="OK"], ' +
        'button[data-display="Close"], button[aria-label="Close"], .ui-dialog-titlebar-close, ' +
        'button[data-display="Yes"]'
      );

      if (closeBtn) {
        triggerClick(closeBtn);
        await microDelay(speedConfig.actionDelay);
        return msg;
      }
    }
    return null;
  }

  async function handleAutomationError(payload, err) {
    try {
      logMessage(`[Auto-Heal] Handling error for VIN ${payload.vin}: ${err.message}`, 'warning');
      const alertMsg = await checkAndDismissAlerts();
      if (alertMsg) {
        logMessage(`[Auto-Heal] Dismissed dialog: "${alertMsg}"`, 'info');
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // MAIN ORCHESTRATION
  // ═══════════════════════════════════════════════════════════════

  async function processRow(payload) {
    const { vin, battery_no, status, technician } = payload;
    logMessage(`Starting VIN: ${vin}`, 'info');

    await waitPageReady();

    // STEP 1: Search VIN via Siebel Search Pane
    await queryByVIN(vin);

    // STEP 2: Click VIN Drilldown in Search Results Panel
    await clickVINDrilldown(vin);

    // STEP 3-9: PDI Details, Technician, Status, Battery Clear, Save, Submit
    await automatePDI(battery_no, status, technician);

    logMessage(`VIN ${vin} completed successfully!`, 'success');
  }

  // ═══════════════════════════════════════════════════════════════
  // STEP 1: SEARCH VIN VIA SIEBEL SEARCH PANE
  // Handles cold-start: first invocation gets longer warm-up time
  // ═══════════════════════════════════════════════════════════════

  let _searchPaneWarmedUp = false;

  async function queryByVIN(vin) {
    console.log('[Siebel Automator Pro] Step 1: Searching VIN via Search Pane:', vin);

    // Attempt 1: Standard search pane approach
    let success = await attemptSearchPaneQuery(vin, _searchPaneWarmedUp ? 3000 : 5000);
    if (success) {
      _searchPaneWarmedUp = true;
      return;
    }

    // Attempt 2: Retry with longer timeouts (cold-start recovery)
    logMessage(`[Search] First attempt failed for ${vin}. Retrying with extended timeouts...`, 'warning');
    await microDelay(500);
    success = await attemptSearchPaneQuery(vin, 6000);
    if (success) {
      _searchPaneWarmedUp = true;
      return;
    }

    // Attempt 3: Fallback to standard applet query (only if applet exists)
    console.log('[Siebel Automator Pro] Search pane failed. Trying standard applet query fallback...');
    try {
      const applet = getApplet("Auto Vehicle List Applet");
      applet.InvokeMethod("NewQuery");
      await waitPageReady();

      const vinCtrl = findControl(applet, ["VIN", "Serial Number", "Asset Number", "Serial_Number"]);
      if (!vinCtrl) throw new Error('VIN query control not found in applet.');

      setControlValue(applet, vinCtrl, vin);
      await waitPageReady();
      applet.InvokeMethod("ExecuteQuery");
      await waitPageReady();

      let numRows = 0;
      try { numRows = applet.GetBusComp().GetNumRows(); } catch (e) { /* ignore */ }
      if (numRows === 0) throw new Error(`VIN ${vin} not found in Siebel CRM database.`);
    } catch (fallbackError) {
      // If applet doesn't exist in this view, provide a clear error
      const msg = fallbackError.message || String(fallbackError);
      if (msg.includes('not found')) {
        throw new Error(
          `VIN search failed: Search pane could not locate "${vin}" and the Vehicle List Applet is not available in the current view. ` +
          `Please ensure you are on the correct Siebel screen (e.g., Vehicles or Service Requests).`
        );
      }
      throw fallbackError;
    }
  }

  /**
   * Attempts the search pane query with a configurable input wait timeout.
   * Returns true if search results were found, false otherwise.
   */
  async function attemptSearchPaneQuery(vin, inputWaitMs) {
    try {
      await openSearchPane();

      // Wait for search pane to fully render (critical on first open)
      const paneReady = await waitForCondition(() => {
        const pane = document.querySelector('#srchpanecontainer');
        return pane && !pane.classList.contains('forcehide') &&
               (pane.querySelector('#findcombobox') || pane.querySelector('input') || pane.querySelector('select'));
      }, inputWaitMs);

      if (!paneReady) {
        console.warn('[Siebel Automator Pro] Search pane did not fully render in time.');
        return false;
      }

      const categorySet = selectSearchCategory("Vehicles");
      if (categorySet) {
        console.log('[Siebel Automator Pro] "Vehicles" category selected.');
        // Wait for category change to take effect (inputs may re-render)
        await microDelay(speedConfig.settleDelay * 2);
      }

      let vinInput = await waitForElement('#field_textbox_0', document, inputWaitMs);

      if (!vinInput) {
        const findFieldsBox = document.querySelector('#findfieldsbox');
        if (findFieldsBox) {
          const firstField = findFieldsBox.querySelector('div:nth-of-type(1)');
          if (firstField) {
            triggerClick(firstField);
            await microDelay(speedConfig.actionDelay);
          }
        }
        vinInput = await waitForElement('#field_textbox_0', document, 2000) || findSearchPaneInput("VIN");
      }

      if (!vinInput) {
        console.warn('[Siebel Automator Pro] VIN input field not detected in search pane.');
        return false;
      }

      vinInput.focus();
      vinInput.value = '';
      await microDelay(50);
      vinInput.value = vin;
      vinInput.dispatchEvent(new Event('input', { bubbles: true }));
      vinInput.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[Siebel Automator Pro] VIN entered in search field:', vin);
      await microDelay(speedConfig.actionDelay);

      const goClicked = await clickSearchGoButton(vinInput);
      if (goClicked) {
        await waitPageReady();
        const hasResults = await waitForSearchResults(vin, 10000);
        if (hasResults) {
          console.log('[Siebel Automator Pro] Step 1 complete: Search results rendered.');
          return true;
        }
      }
    } catch (e) {
      console.warn('[Siebel Automator Pro] Search pane attempt error:', e);
    }

    return false;
  }

  async function openSearchPane() {
    const pane = document.querySelector('#srchpanecontainer');
    if (pane && !pane.classList.contains('forcehide') && (pane.classList.contains('siebui-search-pane-show') || isVisible(pane))) {
      return;
    }

    const searchIcon = document.querySelector('#srch_icon_new') ||
                       document.querySelector('.siebui-icon-search') ||
                       document.querySelector('#s_srch_new') ||
                       document.querySelector('[title="Search"].siebui-search-tb-btn');

    if (searchIcon) {
      triggerClick(searchIcon);
      await microDelay(speedConfig.actionDelay * 2);
      await waitPageReady();

      // Wait for the pane to actually appear visible (up to 4 seconds)
      await waitForCondition(() => {
        const p = document.querySelector('#srchpanecontainer');
        return p && !p.classList.contains('forcehide') && isVisible(p);
      }, 4000);

      const paneAfter = document.querySelector('#srchpanecontainer');
      if (paneAfter) {
        if (paneAfter.classList.contains('forcehide')) {
          paneAfter.classList.remove('forcehide');
        }
        if (!paneAfter.classList.contains('siebui-search-pane-show')) {
          paneAfter.classList.add('siebui-search-pane-show');
        }
        await microDelay(speedConfig.settleDelay);
      }
    }
  }

  function selectSearchCategory(category) {
    const selectors = [
      '#findcombobox',
      'select[id*="findcombo"]',
      'select.siebui-advance-find',
      'select[aria-label*="Find"]',
      'select[id*="srch"]',
      'select[id*="find"]',
      'select.siebui-find-select'
    ];

    for (const sel of selectors) {
      const select = document.querySelector(sel);
      if (!select) continue;

      for (let i = 0; i < select.options.length; i++) {
        const optText = select.options[i].text.trim().toLowerCase();
        const optVal = select.options[i].value.trim().toLowerCase();
        if (optText === category.toLowerCase() || optVal === category.toLowerCase() ||
            optText.includes(category.toLowerCase())) {
          if (select.selectedIndex !== i) {
            select.selectedIndex = i;
            select.dispatchEvent(new Event('change', { bubbles: true }));
          }
          return true;
        }
      }
    }
    return false;
  }

  function findSearchPaneInput(labelName) {
    const containers = document.querySelectorAll(
      '#srchpanecontainer, .siebui-search-pane-results, ' +
      '.siebui-find-pane, .siebui-srch-pane, ' +
      '#s_srch_div, #s_find_div, [id*="srch"], [id*="find"]'
    );

    for (const container of containers) {
      if (!isVisible(container)) continue;

      const labelEls = Array.from(container.querySelectorAll('td, label, span, div.siebui-label, .PageItemLabel, th'));
      for (const labelEl of labelEls) {
        if (labelEl.textContent.trim().toLowerCase() === labelName.toLowerCase()) {
          const nextEl = labelEl.nextElementSibling;
          if (nextEl) {
            const input = nextEl.querySelector('input') || (nextEl.tagName === 'INPUT' ? nextEl : null);
            if (input) return input;
          }
          const row = labelEl.closest('tr, .siebui-row, .ui-helper-clearfix, div');
          if (row) {
            const input = row.querySelector('input[type="text"], input:not([type])');
            if (input) return input;
          }
        }
      }
    }

    const inputs = document.querySelectorAll('input');
    const labelLower = labelName.toLowerCase();
    for (const input of inputs) {
      if (!isVisible(input)) continue;
      const ariaLabel = (input.getAttribute('aria-label') || '').toLowerCase();
      const name = (input.getAttribute('name') || '').toLowerCase();
      const id = (input.getAttribute('id') || '').toLowerCase();
      const title = (input.getAttribute('title') || '').toLowerCase();

      if (ariaLabel.includes(labelLower) || name.includes(labelLower) || title.includes(labelLower) || id.includes(labelLower)) {
        return input;
      }
    }

    return null;
  }

  async function clickSearchGoButton(vinInput) {
    const exactGoBtn = document.querySelector('#find_field_button');
    if (exactGoBtn && isVisible(exactGoBtn)) {
      triggerClick(exactGoBtn);
      return true;
    }

    const goBtnSelectors = [
      'button[title*="Go"]', 'button[data-display="Go"]', 'button[aria-label*="Go"]',
      'button.siebui-icon-findgo', '.siebui-icon-findgo', '.siebui-icon-go',
      'button[title*="Search"]', 'button[title*="Find"]', 'button[id*="go"]'
    ];

    const btn = document.querySelector(goBtnSelectors.join(', '));
    if (btn && isVisible(btn)) {
      triggerClick(btn);
      return true;
    }

    if (vinInput) {
      vinInput.focus();
      vinInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      vinInput.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', keyCode: 13, bubbles: true }));
      vinInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
      return true;
    }

    return false;
  }

  async function waitForSearchResults(vin, timeoutMs = 8000) {
    const upperVin = vin.toUpperCase();
    return waitForCondition(() => {
      const container = document.querySelector('#srchpanecontainer, .siebui-search-pane-results');
      if (container) {
        const rows = container.querySelectorAll('table.ui-jqgrid-btable tr.jqgrow');
        for (const row of rows) {
          if (row.textContent.toUpperCase().includes(upperVin)) return true;
        }

        const counter = container.querySelector('.siebui-row-counter');
        if (counter && !counter.textContent.includes('No Records') && counter.textContent.match(/\d+\s*-\s*\d+/)) {
          return true;
        }
      }
      return false;
    }, timeoutMs);
  }

  // ═══════════════════════════════════════════════════════════════
  // STEP 2: CLICK VIN IN SEARCH RESULTS PANEL
  // ═══════════════════════════════════════════════════════════════

  async function clickVINDrilldown(vin) {
    console.log('[Siebel Automator Pro] Step 2: Clicking VIN in Search Results panel for:', vin);
    const upperVin = vin.toUpperCase();

    const exactLink = await waitForElement('#srchpanecontainer a.drilldown[name="Title"], td[id$="_s_1001_l_title"] a', document, 3000);
    if (exactLink && exactLink.textContent.trim().toUpperCase() === upperVin) {
      console.log('[Siebel Automator Pro] Found VIN drilldown via exact selector. Clicking...');
      triggerClick(exactLink);
      await waitPageReady();
      return;
    }

    const searchContainer = document.querySelector('#srchpanecontainer, .siebui-search-pane-results');
    if (searchContainer) {
      const rows = searchContainer.querySelectorAll('table.ui-jqgrid-btable tr.jqgrow');
      for (const row of rows) {
        if (row.textContent.toUpperCase().includes(upperVin)) {
          const link = row.querySelector('a');
          if (link) {
            triggerClick(link);
          } else {
            const titleCell = row.querySelector('td[id$="_title"]') || row.querySelector('td:nth-child(3)');
            triggerClick(titleCell || row);
          }
          await waitPageReady();
          return;
        }
      }

      const allClickables = searchContainer.querySelectorAll('a, span, td, div');
      for (const el of allClickables) {
        if (el.textContent.trim().toUpperCase() === upperVin && el.children.length <= 2) {
          triggerClick(el);
          await waitPageReady();
          return;
        }
      }
    }

    try {
      const view = SiebelApp.S_App.GetActiveView();
      const appletMap = view.GetAppletMap();
      for (const name in appletMap) {
        if (!appletMap.hasOwnProperty(name)) continue;
        const lowerName = name.toLowerCase();
        if (lowerName.includes('search') || lowerName.includes('result') || lowerName.includes('srch')) {
          const applet = appletMap[name];
          const bc = applet.GetBusComp();
          if (bc && bc.GetNumRows() > 0) {
            applet.InvokeMethod("DrillDown");
            await waitPageReady();
            return;
          }
        }
      }
    } catch (e) { /* ignore */ }

    const drilldownLinks = document.querySelectorAll('a.drilldown');
    for (const link of drilldownLinks) {
      if (link.textContent.trim().toUpperCase() === upperVin) {
        triggerClick(link);
        await waitPageReady();
        return;
      }
    }

    console.warn('[Siebel Automator Pro] Step 2: Drilldown link not directly found, continuing.');
  }

  // ═══════════════════════════════════════════════════════════════
  // STEP 3 TO 9: PDI AUTOMATION
  // ═══════════════════════════════════════════════════════════════

  async function automatePDI(batteryNo, status, technician) {
    // 3. Detail Tab: Navigate to PDI tab (skips reload if already active!)
    await clickDetailTab("PDI");

    // 4. Re-fetch fresh applet instance
    const pdiApplet = getApplet("HHML PDI List Applet");
    const bc = pdiApplet.GetBusComp();
    if (!bc) throw new Error('PDI BusComp not initialized.');

    // Check if PDI is already done
    let numRows = 0;
    try { numRows = bc.GetNumRows(); } catch (e) { /* ignore */ }

    if (numRows > 0) {
      let currentStatus = '';
      for (const fieldName of ['Status', 'PDI Status', 'HHML PDI Status', 'HHML_PDI_Status']) {
        try {
          const val = bc.GetFieldValue(fieldName);
          if (val && val.trim()) {
            currentStatus = val.trim();
            break;
          }
        } catch (e) { /* ignore */ }
      }

      console.log('[Siebel Automator Pro] Existing PDI Status:', currentStatus);
      if (/Closed|Submitted|Completed|Done/i.test(currentStatus) || (status && currentStatus.toLowerCase() === status.toLowerCase())) {
        logMessage(`PDI is already marked as ${currentStatus}. Skipping modification.`, 'info');
        return;
      }
    } else {
      // Create new record
      await createNewRecord(pdiApplet);
    }

    // 5. Technician selection (High-speed Fast-Path)
    await selectTechnicianIfNeeded(pdiApplet, technician);

    // 6. Status assignment
    if (status) {
      const freshApplet = getApplet("HHML PDI List Applet");
      const statusCtrl = findControl(freshApplet, ["PDI Status", "Status", "HHML PDI Status"]);
      if (statusCtrl) {
        setControlValue(freshApplet, statusCtrl, status);
      }
    }

    // 7. Clear auto-filled Battery Number
    const freshApplet = getApplet("HHML PDI List Applet");
    await clearBatteryNumber(freshApplet);

    // 8. Save Record
    console.log('[Siebel Automator Pro] Saving PDI record...');
    try {
      freshApplet.InvokeMethod("WriteRecord");
    } catch (e) {
      throw new Error(`Save failed: ${e.message}`);
    }
    await waitPageReady();

    const saveAlert = await checkAndDismissAlerts();
    if (saveAlert) {
      throw new Error(`Save failed with Siebel error: ${saveAlert}`);
    }

    // 9. Submit PDI
    await submitPDI();
    await waitPageReady();

    const submitAlert = await checkAndDismissAlerts();
    if (submitAlert) {
      throw new Error(`Submit failed with Siebel error: ${submitAlert}`);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // DETAIL TAB CLICK (SKIPS IF ALREADY ACTIVE TO SAVE 3-4 SECONDS)
  // ═══════════════════════════════════════════════════════════════

  async function clickDetailTab(tabName) {
    const upper = tabName.toUpperCase();
    const selectors = [
      '.siebui-nav-tabView a',
      '#s_sctrl_tabView a',
      '.ui-tabs-anchor',
      '.siebui-subview-navs a'
    ];

    for (const sel of selectors) {
      const tabs = document.querySelectorAll(sel);
      for (const tab of tabs) {
        if (tab.textContent.trim().toUpperCase() === upper) {
          // If already on PDI tab, skip reloading the entire view!
          const parent = tab.closest('li, [role="tab"]');
          const isAlreadyActive = (parent && (parent.classList.contains('ui-tabs-active') || parent.classList.contains('siebui-active'))) ||
                                  tab.getAttribute('aria-selected') === 'true';
          if (isAlreadyActive) {
            console.log('[Siebel Automator Pro] PDI tab is already active, skipping redundant reload.');
            return;
          }

          triggerClick(tab);
          await waitPageReady();
          return;
        }
      }
    }

    for (const el of document.querySelectorAll('a, [role="tab"]')) {
      if (el.textContent.trim().toUpperCase() === upper) {
        const parent = el.closest('li, [role="tab"]');
        const isAlreadyActive = (parent && (parent.classList.contains('ui-tabs-active') || parent.classList.contains('siebui-active'))) ||
                                el.getAttribute('aria-selected') === 'true';
        if (isAlreadyActive) return;

        triggerClick(el);
        await waitPageReady();
        return;
      }
    }

    throw new Error(`Tab "${tabName}" not found in current view.`);
  }

  // ═══════════════════════════════════════════════════════════════
  // TECHNICIAN SELECTION (TURBO-SPEED — METHOD CACHE + PARALLEL)
  // ═══════════════════════════════════════════════════════════════

  // Cache which method worked last time so subsequent VINs skip dead paths
  let _techMethodCache = null; // 'autocomplete' | 'pickicon' | 'dblclick' | 'f2' | null

  async function selectTechnicianIfNeeded(pdiApplet, technician) {
    const bc = pdiApplet.GetBusComp();
    let numRows = 0;
    try { numRows = bc ? bc.GetNumRows() : 0; } catch (e) { /* ignore */ }
    if (numRows === 0) return;

    let currentTech = '';
    try {
      if (bc) currentTech = bc.GetFieldValue('HHML_Mechanic_Full_Name') || '';
    } catch (e) { /* ignore */ }

    if (currentTech.trim()) {
      console.log('[Siebel Automator Pro] Technician already assigned:', currentTech);
      return;
    }

    const tStart = Date.now();
    const appletDiv = getAppletDiv(pdiApplet);
    if (!appletDiv) return;

    const row = appletDiv.querySelector(
      'table.ui-jqgrid-btable tr.jqgrow.ui-state-highlight,' +
      'table.ui-jqgrid-btable tr.jqgrow[aria-selected="true"],' +
      'table.ui-jqgrid-btable tr.jqgrow'
    );
    if (!row) return;

    let techCell = row.querySelector(
      'td[aria-describedby*="HHML_Mechanic_Full_Name"],' +
      'td[aria-describedby*="Mechanic"],' +
      'td[id*="HHML_Mechanic_Full_Name"]'
    );

    if (!techCell) {
      const headers = Array.from(document.querySelectorAll('th'));
      const techHeaderIdx = headers.findIndex(th => /technician|mechanic/i.test(th.textContent));
      if (techHeaderIdx !== -1) {
        techCell = row.querySelector(`td:nth-child(${techHeaderIdx + 1})`);
      }
    }
    if (!techCell) return;

    // Focus the technician cell — wait briefly for input to render
    triggerClick(techCell);
    await microDelay(30);

    // ────────────────────────────────────────────────────────────
    // CACHED FAST PATH: If we already know what worked, use it
    // ────────────────────────────────────────────────────────────
    if (_techMethodCache) {
      const result = await executeTechMethod(_techMethodCache, techCell, appletDiv, technician, tStart);
      if (result) return;
      // Cache miss (view changed?), fall through to full discovery
      _techMethodCache = null;
    }

    // ────────────────────────────────────────────────────────────
    // DISCOVERY: Try all methods, cache the winner
    // ────────────────────────────────────────────────────────────

    // ── METHOD 1: Direct Autocomplete Typing (~0.3s) ──
    if (technician && technician.trim()) {
      const searchWord = technician.trim().split(/\s+/)[0];
      let techInput = techCell.querySelector('input') || findTechInput(appletDiv);
      if (techInput) {
        techInput.focus();
        techInput.value = '';
        techInput.value = searchWord;
        techInput.dispatchEvent(new Event('input', { bubbles: true }));
        techInput.dispatchEvent(new Event('change', { bubbles: true }));

        // Short autocomplete wait — bail early if no dropdown appears in 200ms
        const acDone = await waitForAutocomplete(technician, 500);
        if (acDone) {
          _techMethodCache = 'autocomplete';
          logMessage(`[Tech Selector] ⚡ Matched "${technician}" in ${Date.now() - tStart}ms!`, 'success');
          return;
        }
        // Clear the typed text so it doesn't interfere with pick dialog
        techInput.value = '';
        techInput.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }

    // ── METHOD 2: Pick Button Click ──
    const pickIcon = techCell.querySelector(
      'button[title*="Pick"], span.siebui-icon-pick, button.siebui-icon-pick, ' +
      '.siebui-icon-popup, [class*="pick"], [class*="popup"]'
    );

    if (pickIcon) {
      triggerClick(pickIcon);
      const selected = await waitForPickDialog(technician, 2500);
      if (selected) {
        _techMethodCache = 'pickicon';
        logMessage(`[Tech Selector] ⚡ Selected technician via pick icon in ${Date.now() - tStart}ms`, 'info');
        return;
      }
    }

    // ── METHOD 3: Double-Click Cell ──
    triggerClick(techCell);
    await microDelay(20);
    techCell.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }));

    const dblSelected = await waitForPickDialog(technician, 2500);
    if (dblSelected) {
      _techMethodCache = 'dblclick';
      logMessage(`[Tech Selector] ⚡ Selected technician via double-click in ${Date.now() - tStart}ms`, 'info');
      return;
    }

    // ── METHOD 4: F2 Key Fallback ──
    const techInputFallback = findTechInput(appletDiv);
    if (techInputFallback) {
      techInputFallback.focus();
      techInputFallback.dispatchEvent(new KeyboardEvent('keydown', { key: 'F2', keyCode: 113, code: 'F2', bubbles: true, cancelable: true }));
      const f2Selected = await waitForPickDialog(technician, 2000);
      if (f2Selected) {
        _techMethodCache = 'f2';
        return;
      }
    }

    // Verify
    let postCheck = '';
    try {
      postCheck = pdiApplet.GetBusComp()?.GetFieldValue('HHML_Mechanic_Full_Name') || '';
    } catch (e) { /* ignore */ }

    if (postCheck.trim()) {
      console.log('[Siebel Automator Pro] Technician verified:', postCheck);
    }
  }

  /**
   * Re-execute a previously successful method (skips dead paths).
   */
  async function executeTechMethod(method, techCell, appletDiv, technician, tStart) {
    try {
      if (method === 'autocomplete' && technician && technician.trim()) {
        const searchWord = technician.trim().split(/\s+/)[0];
        let techInput = techCell.querySelector('input') || findTechInput(appletDiv);
        if (techInput) {
          techInput.focus();
          techInput.value = '';
          techInput.value = searchWord;
          techInput.dispatchEvent(new Event('input', { bubbles: true }));
          techInput.dispatchEvent(new Event('change', { bubbles: true }));
          const acDone = await waitForAutocomplete(technician, 500);
          if (acDone) {
            logMessage(`[Tech Selector] ⚡ Cached autocomplete matched "${technician}" in ${Date.now() - tStart}ms!`, 'success');
            return true;
          }
        }
      } else if (method === 'pickicon') {
        const pickIcon = techCell.querySelector(
          'button[title*="Pick"], span.siebui-icon-pick, button.siebui-icon-pick, ' +
          '.siebui-icon-popup, [class*="pick"], [class*="popup"]'
        );
        if (pickIcon) {
          triggerClick(pickIcon);
          const selected = await waitForPickDialog(technician, 2500);
          if (selected) {
            logMessage(`[Tech Selector] ⚡ Cached pick icon in ${Date.now() - tStart}ms`, 'info');
            return true;
          }
        }
      } else if (method === 'dblclick') {
        techCell.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }));
        const selected = await waitForPickDialog(technician, 2500);
        if (selected) {
          logMessage(`[Tech Selector] ⚡ Cached double-click in ${Date.now() - tStart}ms`, 'info');
          return true;
        }
      } else if (method === 'f2') {
        const techInput = findTechInput(appletDiv);
        if (techInput) {
          techInput.focus();
          techInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'F2', keyCode: 113, code: 'F2', bubbles: true, cancelable: true }));
          const selected = await waitForPickDialog(technician, 2000);
          if (selected) return true;
        }
      }
    } catch (e) {
      console.warn('[Siebel Automator Pro] Cached tech method failed:', method, e);
    }
    return false;
  }

  async function waitForAutocomplete(targetTech, timeoutMs = 500) {
    const start = Date.now();
    const lower = (targetTech || '').toLowerCase();
    let noDropdownCount = 0;

    while (Date.now() - start < timeoutMs) {
      const acItems = Array.from(
        document.querySelectorAll('ul.ui-autocomplete:not([style*="display: none"]) li.ui-menu-item')
      ).filter(el => el.textContent.trim());

      if (acItems.length > 0) {
        let chosen = acItems[0];
        for (const item of acItems) {
          const txt = item.textContent.toLowerCase();
          if (txt.includes(lower) || lower.includes(txt)) {
            chosen = item;
            break;
          }
        }
        triggerClick(chosen.querySelector('a') || chosen);
        return true;
      }

      noDropdownCount++;
      // If no dropdown appeared after 200ms of polling, bail early
      if (noDropdownCount > 10 && (Date.now() - start) > 200) {
        return false;
      }

      await microDelay(15);
    }
    return false;
  }

  async function waitForPickDialog(targetTech, timeoutMs = 2500) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const pickDialogs = document.querySelectorAll(
        '.ui-dialog, .siebui-popup-dialog, [class*="AppletStylePopup"], #s_SWEPopup_div, .siebui-popup-container'
      );

      for (const dialog of pickDialogs) {
        const rows = dialog.querySelectorAll('table.ui-jqgrid-btable tr.jqgrow, table tr.jqgrow');
        if (rows.length > 0) {
          return await pickTechnicianFromRows(dialog, rows, targetTech);
        }
      }

      // Also check for autocomplete popup during pick wait
      const acItems = Array.from(
        document.querySelectorAll('ul.ui-autocomplete:not([style*="display: none"]) li.ui-menu-item')
      ).filter(el => el.textContent.trim());

      if (acItems.length > 0) {
        const pick = acItems[0];
        triggerClick(pick.querySelector('a') || pick);
        return true;
      }

      await microDelay(15);
    }
    return false;
  }

  async function pickTechnicianFromRows(dialog, rows, targetTech) {
    let matchedIndex = -1;
    const options = [];

    rows.forEach((row, index) => {
      const cells = Array.from(row.querySelectorAll('td'));
      const fullText = cells.map(c => c.textContent.trim()).filter(Boolean).join(' ');
      const nameText = row.querySelector('td:nth-child(2)')?.textContent?.trim() ||
                       row.querySelector('td[aria-describedby*="Name"]')?.textContent?.trim() ||
                       fullText;
      options.push({ index, name: nameText, fullText, row });
    });

    if (targetTech && targetTech.trim()) {
      const lowerTarget = targetTech.trim().toLowerCase();
      for (let i = 0; i < options.length; i++) {
        const lowerOpt = options[i].name.toLowerCase();
        const lowerFull = options[i].fullText.toLowerCase();
        if (lowerOpt === lowerTarget || lowerOpt.includes(lowerTarget) || lowerTarget.includes(lowerOpt) ||
            lowerFull.includes(lowerTarget)) {
          matchedIndex = i;
          logMessage(`[Tech Selector] Matched technician: "${options[i].name}" for "${targetTech}"`, 'info');
          break;
        }
      }
    }

    if (matchedIndex === -1) {
      matchedIndex = 0;
      logMessage(`[Tech Selector] Selected primary available technician: "${options[0]?.name || 'Primary'}"`, 'info');
    }

    const selectedOption = options[matchedIndex];
    const targetRow = selectedOption.row;

    // 1. Click + double-click in rapid succession (no delay between)
    triggerClick(targetRow);
    targetRow.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }));
    await microDelay(30);

    // 2. Click OK button immediately
    const okBtn = findOkButton(dialog);
    if (okBtn) {
      triggerClick(okBtn);
    } else {
      targetRow.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
    }

    await waitPageReady();
    return true;
  }

  function findTechInput(container) {
    const selectors = [
      'td[aria-describedby*="HHML_Mechanic_Full_Name"] input',
      'td[id*="HHML_Mechanic_Full_Name"] input',
      'input[name*="Mechanic"]',
      'input[aria-label*="Technician"]',
      'input[aria-label*="Mechanic"]'
    ];
    for (const sel of selectors) {
      const el = container.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  async function createNewRecord(pdiApplet) {
    const appletDiv = getAppletDiv(pdiApplet);
    let clicked = false;
    if (appletDiv) {
      const addBtn = appletDiv.querySelector(
        'button[title*="Add"], button[title*="New"], ' +
        'button[aria-label*="Add"], button[aria-label*="New"], ' +
        '.siebui-icon-add, [id*="NewRecord"], [id*="new_record"]'
      );
      if (addBtn && isVisible(addBtn)) {
        console.log('[Siebel Automator Pro] Creating record via UI Add button.');
        triggerClick(addBtn);
        await waitPageReady();
        clicked = true;
      }
    }

    if (!clicked) {
      console.log('[Siebel Automator Pro] Falling back to InvokeMethod("NewRecord").');
      pdiApplet.InvokeMethod("NewRecord");
      await waitPageReady();
    }
  }

  function findOkButton(dialog) {
    const selectors = [
      'button[data-display="OK"]',
      'button[aria-label="OK"]',
      'button[title="OK"]',
      'button[title*="OK"]',
      'button[id*="Ok"]',
      'button[id*="OK"]',
      '.ui-dialog-buttonpane button',
      '.ui-dialog-buttonset button'
    ];
    for (const sel of selectors) {
      const btn = dialog.querySelector(sel);
      if (btn && isVisible(btn)) return btn;
    }
    for (const b of dialog.querySelectorAll('button')) {
      if (b.textContent.trim().toUpperCase() === 'OK') return b;
    }
    return null;
  }

  // ═══════════════════════════════════════════════════════════════
  // SUBMIT PDI
  // ═══════════════════════════════════════════════════════════════

  async function submitPDI() {
    const submitBtn = document.querySelector(
      'button[data-display="Submit"][class*="submitpdi"],' +
      'button.siebui-icon-submitpdi,' +
      'button[data-display="Submit"],' +
      'button[aria-label*="Submit"]'
    );

    if (submitBtn && isVisible(submitBtn)) {
      triggerClick(submitBtn);
      return;
    }

    try {
      const applet = getApplet("HHML PDI List Applet");
      applet.InvokeMethod("SubmitPDI");
    } catch (e) {
      try {
        const applet = getApplet("Service Request List");
        applet.InvokeMethod("SubmitPDI");
      } catch (e2) {
        console.warn('[Siebel Automator Pro] Submit method invocation fallback warning:', e2);
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // CLEAR AUTO-FILLED BATTERY NUMBER (STREAMLINED & FAST)
  // ═══════════════════════════════════════════════════════════════

  async function clearBatteryNumber(applet) {
    try {
      const batteryInput = document.querySelector('[id$="_HMCL_Battery_Number"]') ||
                           document.querySelector('input[aria-label*="Battery"]') ||
                           document.querySelector('input[name*="Battery"]');
      if (batteryInput) {
        batteryInput.focus();
        batteryInput.value = '';
        batteryInput.dispatchEvent(new Event('input', { bubbles: true }));
        batteryInput.dispatchEvent(new Event('change', { bubbles: true }));
        batteryInput.dispatchEvent(new Event('blur', { bubbles: true }));
      }

      const batteryCtrl = findControl(applet, [
        "Battery #", "Battery Number", "HMCL_Battery_Number", "HHML Battery Number"
      ]);
      if (batteryCtrl) {
        try {
          const pm = applet.GetPModel();
          if (pm) {
            let focusEvt = 'cycleCtrlFocus', blurEvt = 'cycleCtrlBlur';
            try {
              const c = SiebelJS.Dependency("SiebelApp.Constants");
              focusEvt = c.get("PHYEVENT_CONTROL_FOCUS") || focusEvt;
              blurEvt = c.get("PHYEVENT_CONTROL_BLUR") || blurEvt;
            } catch (e) { /* use default */ }
            pm.OnControlEvent(focusEvt, batteryCtrl);
            pm.OnControlEvent(blurEvt, batteryCtrl, '');
          }
        } catch (e) { /* ignore */ }

        try {
          const fn = batteryCtrl.GetFieldName();
          if (fn) {
            applet.GetBusComp().SetFieldValue(fn, '');
          }
        } catch (e) { /* ignore */ }
      }
    } catch (e) {
      console.warn('[Siebel Automator Pro] Clear battery warning:', e);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // CORE SIEBEL CRM HELPERS
  // ═══════════════════════════════════════════════════════════════

  function getApplet(appletName) {
    const view = SiebelApp.S_App.GetActiveView();
    if (!view) throw new Error('No active Siebel view.');

    try {
      const a = view.GetApplet(appletName);
      if (a) return a;
    } catch (e) { /* ignore */ }

    const map = view.GetAppletMap();
    const lower = appletName.toLowerCase();
    for (const name in map) {
      if (map.hasOwnProperty(name)) {
        const nl = name.toLowerCase();
        if (nl === lower || nl.includes(lower) || lower.includes(nl)) {
          return map[name];
        }
      }
    }
    throw new Error(`Applet "${appletName}" not found.`);
  }

  function getAppletDiv(applet) {
    try {
      const pm = applet.GetPModel();
      if (pm) {
        const fullId = pm.Get("GetFullId");
        if (fullId) {
          const div = document.getElementById("s_" + fullId + "_div");
          if (div) return div;
        }
      }
    } catch (e) { /* ignore */ }

    for (const div of document.querySelectorAll('[id^="s_"][id$="_div"]')) {
      if (div.querySelector('[id*="HHML_Mechanic"], [aria-describedby*="HHML_Mechanic"]')) {
        return div;
      }
    }

    for (const div of document.querySelectorAll('[id^="s_"][id$="_div"]')) {
      const summary = div.querySelector('table.ui-jqgrid-btable[summary*="Service Request"]');
      if (summary) return div;
    }

    return null;
  }

  function findControl(applet, names) {
    let controls;
    try { controls = applet.GetControls(); } catch (e) { /* ignore */ }
    if (!controls) {
      try { controls = applet.GetPModel()?.Get("GetControls"); } catch (e) { /* ignore */ }
    }
    if (!controls) return null;

    for (const key in controls) {
      if (!controls.hasOwnProperty(key)) continue;
      const ctrl = controls[key];
      let n = '', dn = '', fn = '';
      try { n = ctrl.GetName() || ''; } catch (e) { /* ignore */ }
      try { dn = ctrl.GetDisplayName ? (ctrl.GetDisplayName() || '') : ''; } catch (e) { /* ignore */ }
      try { fn = ctrl.GetFieldName ? (ctrl.GetFieldName() || '') : ''; } catch (e) { /* ignore */ }

      for (const name of names) {
        const lc = name.toLowerCase();
        if (n.toLowerCase() === lc || dn.toLowerCase() === lc || fn.toLowerCase() === lc) {
          return ctrl;
        }
      }
    }
    return null;
  }

  function setControlValue(applet, control, value) {
    try {
      const pm = applet.GetPModel();
      if (pm) {
        let focusEvt = 'cycleCtrlFocus', blurEvt = 'cycleCtrlBlur';
        try {
          const c = SiebelJS.Dependency("SiebelApp.Constants");
          focusEvt = c.get("PHYEVENT_CONTROL_FOCUS") || focusEvt;
          blurEvt = c.get("PHYEVENT_CONTROL_BLUR") || blurEvt;
        } catch (e) { /* defaults */ }

        pm.OnControlEvent(focusEvt, control);
        pm.OnControlEvent(blurEvt, control, value);
        return;
      }
    } catch (e) { /* fallback */ }

    try {
      const fn = control.GetFieldName ? control.GetFieldName() : '';
      if (fn) {
        applet.GetBusComp().SetFieldValue(fn, value);
      }
    } catch (e) { /* ignore */ }
  }

  function triggerClick(element) {
    if (!element) return;
    for (const type of ['mousedown', 'mouseup', 'click']) {
      element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    }
  }
})();
