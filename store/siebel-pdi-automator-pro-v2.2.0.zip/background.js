/**
 * Siebel PDI Automator Pro — Background Service Worker
 * ─────────────────────────────────────────────────────
 * Manages the automation queue, state persistence, session history,
 * dynamic speed adaptation, network connectivity monitoring, and
 * communication between the popup/side-panel UI and content script.
 *
 * Uses chrome.storage.local for state persistence (queue, results, logs).
 * Uses chrome.alarms for a 1-minute watchdog to recover stuck records.
 * Uses chrome.notifications to alert the user when a batch completes.
 *
 * NO user data is collected or transmitted to any external server.
 * The only network request is a HEAD to connect.heromotocorp.biz/favicon.ico
 * to detect offline/online status for auto-pause/resume.
 */

let state = {
  status: 'IDLE', // IDLE, RUNNING, PAUSED
  queue: [],
  index: 0,
  results: [],
  logs: [],
  currentRowStartTime: null,
  consecutiveErrors: 0,
  isOffline: false,
  wasRunningBeforeOffline: false,
  dynamicSpeed: {
    profile: 'balanced', // turbo, balanced, safe
    interRecordDelay: 300,
    siteHealth: 'Detecting...',
    recentDurations: []
  },
  sessions: [], // Last 5 completed/processed sessions
  settings: {
    maxConsecutiveErrors: 3,  // circuit breaker threshold
    autoRetry: true,          // auto-retry transient error once
    soundEnabled: true,
    notificationsEnabled: true
  }
};

let processingTimeout = null;

// Initialize and restore state from storage
chrome.runtime.onInstalled.addListener(() => {
  saveState();
  setupWatchdogAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  loadState(() => {
    if (state.status === 'RUNNING') {
      state.status = 'PAUSED';
      addLog('Browser restarted during active queue. Automation paused. Click Start to resume.', 'warning');
      saveState();
      broadcastState();
    }
  });
  setupWatchdogAlarm();
});

// Configure SidePanel behavior
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error('[Siebel Automator Pro] SidePanel behavior config failed:', error));
}

// Keep-alive port connections from SidePanel/Popup
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'siebel_pdi_keepalive') {
    port.onDisconnect.addListener(() => {});
  }
});

// MV3 Watchdog Alarm
function setupWatchdogAlarm() {
  chrome.alarms.get('pdi_watchdog', (alarm) => {
    if (!alarm) {
      chrome.alarms.create('pdi_watchdog', { periodInMinutes: 1 });
    }
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'pdi_watchdog') {
    loadState(() => {
      // Periodic internet connectivity check
      checkNetworkConnectivity();

      if (state.status === 'RUNNING' && !state.isOffline) {
        const now = Date.now();
        if (state.currentRowStartTime && (now - state.currentRowStartTime > 70000)) {
          addLog('Watchdog: Current record exceeded 70s threshold. Forcing timeout recovery...', 'warning');
          const currentRow = state.queue[state.index];
          if (currentRow) {
            handleRowResult({
              vin: currentRow.vin,
              status: 'Error',
              errorDetails: 'Watchdog Timeout: Record exceeded 70s response limit.'
            });
          }
        }
      }
    });
  }
});

// Network Connectivity Check
async function checkNetworkConnectivity() {
  try {
    const response = await fetch('https://connect.heromotocorp.biz/favicon.ico', { method: 'HEAD', cache: 'no-store' });
    if (state.isOffline) {
      handleInternetRestored();
    }
  } catch (e) {
    // If request failed due to no internet
    if (!navigator.onLine && !state.isOffline) {
      handleInternetLost();
    }
  }
}

function handleInternetLost() {
  if (state.isOffline) return;
  state.isOffline = true;
  if (state.status === 'RUNNING') {
    state.wasRunningBeforeOffline = true;
    state.status = 'PAUSED';
    clearTimeout(processingTimeout);
  }
  addLog('⚠️ Internet connection lost! Automation paused. Waiting for connection...', 'warning');
  saveState();
  broadcastState();
}

function handleInternetRestored() {
  if (!state.isOffline) return;
  state.isOffline = false;
  addLog('✅ Internet connection restored! Resuming in 2 seconds...', 'success');
  saveState();
  broadcastState();

  if (state.wasRunningBeforeOffline) {
    state.wasRunningBeforeOffline = false;
    state.status = 'RUNNING';
    saveState();
    broadcastState();
    setTimeout(() => {
      processNext();
    }, 2000);
  }
}

// Load state helper
function loadState(callback) {
  chrome.storage.local.get([
    'status', 'queue', 'index', 'results', 'logs', 'currentRowStartTime',
    'consecutiveErrors', 'isOffline', 'wasRunningBeforeOffline',
    'dynamicSpeed', 'sessions', 'settings'
  ], (data) => {
    if (data.status) state.status = data.status;
    if (data.queue) state.queue = data.queue;
    if (data.index !== undefined) state.index = data.index;
    if (data.results) state.results = data.results;
    if (data.logs) state.logs = data.logs;
    if (data.currentRowStartTime !== undefined) state.currentRowStartTime = data.currentRowStartTime;
    if (data.consecutiveErrors !== undefined) state.consecutiveErrors = data.consecutiveErrors;
    if (data.isOffline !== undefined) state.isOffline = data.isOffline;
    if (data.wasRunningBeforeOffline !== undefined) state.wasRunningBeforeOffline = data.wasRunningBeforeOffline;
    if (data.dynamicSpeed) state.dynamicSpeed = { ...state.dynamicSpeed, ...data.dynamicSpeed };
    if (data.sessions) state.sessions = data.sessions;
    if (data.settings) state.settings = { ...state.settings, ...data.settings };
    if (callback) callback();
  });
}

function saveState() {
  // Guard against exceeding chrome.storage.local quota (5MB)
  // Trim logs to 200 entries max
  if (state.logs && state.logs.length > 200) {
    state.logs = state.logs.slice(-200);
  }

  // Trim session results to prevent bloat (keep only essential fields per result)
  if (state.sessions && state.sessions.length > 0) {
    state.sessions = state.sessions.map(sess => ({
      ...sess,
      results: (sess.results || []).map(r => ({
        vin: r.vin,
        status: r.status,
        status_requested: r.status_requested,
        battery_no: r.battery_no,
        technician: r.technician,
        errorDetails: r.errorDetails,
        duration: r.duration,
        timestamp: r.timestamp
      }))
    }));
  }

  try {
    chrome.storage.local.set(state);
  } catch (e) {
    console.error('[Siebel Automator Pro] Storage save error:', e);
    // If quota exceeded, drop oldest sessions
    if (state.sessions && state.sessions.length > 2) {
      state.sessions = state.sessions.slice(-2);
      chrome.storage.local.set(state);
    }
  }
}

function broadcastState() {
  try {
    chrome.runtime.sendMessage({ type: 'STATE_UPDATED', state }).catch(() => {});
  } catch (e) {
    // Popup/SidePanel may not be open — this is expected
  }
}

function addLog(message, level = 'info') {
  state.logs.push({ message, level, timestamp: Date.now() });
  if (state.logs.length > 400) {
    state.logs.shift();
  }
  saveState();
}

// ═══════════════════════════════════════════════════════════════
// DYNAMIC SPEED ADAPTATION ENGINE
// Automatically adapts speed according to website response time
// ═══════════════════════════════════════════════════════════════
function updateDynamicSpeed(latestDuration) {
  if (latestDuration && latestDuration > 0) {
    if (!state.dynamicSpeed.recentDurations) state.dynamicSpeed.recentDurations = [];
    state.dynamicSpeed.recentDurations.push(latestDuration);
    if (state.dynamicSpeed.recentDurations.length > 4) {
      state.dynamicSpeed.recentDurations.shift();
    }

    const avg = state.dynamicSpeed.recentDurations.reduce((a, b) => a + b, 0) / state.dynamicSpeed.recentDurations.length;

    if (avg < 7) {
      // Website is fast! Scale up to Turbo
      state.dynamicSpeed.profile = 'turbo';
      state.dynamicSpeed.interRecordDelay = 200;
      state.dynamicSpeed.siteHealth = `Optimal (${Math.round(avg)}s/VIN)`;
    } else if (avg <= 13) {
      // Website normal
      state.dynamicSpeed.profile = 'balanced';
      state.dynamicSpeed.interRecordDelay = 350;
      state.dynamicSpeed.siteHealth = `Normal (${Math.round(avg)}s/VIN)`;
    } else {
      // Website slow or experiencing network latency! Scale down to Safe
      state.dynamicSpeed.profile = 'safe';
      state.dynamicSpeed.interRecordDelay = 800;
      state.dynamicSpeed.siteHealth = `Lagging (${Math.round(avg)}s/VIN)`;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// SESSION ARCHIVER (SAVE LAST 5 SESSIONS)
// ═══════════════════════════════════════════════════════════════
function archiveCurrentSession() {
  if (!state.results || state.results.length === 0) return;

  const validDurations = state.results.filter(r => r.duration && r.duration > 0);
  const avgSpeed = validDurations.length > 0
    ? Math.round((validDurations.reduce((sum, r) => sum + r.duration, 0) / validDurations.length) * 10) / 10
    : 0;

  const session = {
    id: Date.now(),
    timestamp: Date.now(),
    dateStr: new Date().toLocaleString(),
    total: state.queue.length || state.results.length,
    processed: state.results.length,
    successCount: state.results.filter(r => r.status === 'Success').length,
    errorCount: state.results.filter(r => r.status === 'Error').length,
    skippedCount: state.results.filter(r => r.status === 'Skipped').length,
    avgSpeed: avgSpeed,
    results: [...state.results]
  };

  if (!state.sessions) state.sessions = [];

  // Avoid duplicate archiving
  const lastSession = state.sessions[state.sessions.length - 1];
  if (lastSession && lastSession.results.length === session.results.length && (Date.now() - lastSession.timestamp < 10000)) {
    return;
  }

  state.sessions.push(session);
  // Keep only the last 5 sessions
  if (state.sessions.length > 5) {
    state.sessions = state.sessions.slice(-5);
  }

  addLog(`Session saved to history (Session #${state.sessions.length} • ${session.successCount} Success, ${session.errorCount} Errors).`, 'info');
  saveState();
  broadcastState();
}

function ensureContentScriptInjected(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { type: 'PING' }, (response) => {
      if (chrome.runtime.lastError || !response || response.type !== 'PONG') {
        addLog('Content script not active. Injecting content script...', 'info');
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          files: ['content.js']
        }, () => {
          if (chrome.runtime.lastError) {
            addLog(`Failed to inject content script: ${chrome.runtime.lastError.message}`, 'error');
            resolve(false);
          } else {
            addLog('Content script successfully injected.', 'info');
            setTimeout(() => resolve(true), 600);
          }
        });
      } else {
        resolve(true);
      }
    });
  });
}

function waitTabComplete(tabId) {
  return new Promise((resolve) => {
    const check = () => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          resolve();
          return;
        }
        if (tab.status === 'complete') {
          resolve();
        } else {
          setTimeout(check, 300);
        }
      });
    };
    check();
  });
}

// ═══════════════════════════════════════════════════════════════
// MAIN QUEUE PROCESSING LOOP
// ═══════════════════════════════════════════════════════════════
async function processNext() {
  loadState(async () => {
    if (state.status !== 'RUNNING') return;

    if (state.isOffline) {
      state.status = 'PAUSED';
      state.wasRunningBeforeOffline = true;
      addLog('Cannot process: Waiting for internet connection...', 'warning');
      saveState();
      broadcastState();
      return;
    }

    if (state.index >= state.queue.length) {
      state.status = 'IDLE';
      state.consecutiveErrors = 0;
      addLog('Automation complete! All records in the queue processed.', 'success');

      // Archive completed session to the last 5 sessions history!
      archiveCurrentSession();

      saveState();
      broadcastState();

      if (state.settings.notificationsEnabled && chrome.notifications) {
        const successes = state.results.filter(r => r.status === 'Success').length;
        const errors = state.results.filter(r => r.status === 'Error').length;
        chrome.notifications.create('pdi_batch_complete_' + Date.now(), {
          type: 'basic',
          iconUrl: chrome.runtime.getURL('icons/icon128.png'),
          title: 'Siebel PDI Automation Complete',
          message: `Batch finished: ${successes} Success, ${errors} Errors (${state.queue.length} total). Session saved.`,
          priority: 2
        }, () => {
          if (chrome.runtime.lastError) {
            console.warn('[Siebel Automator Pro] Notification error:', chrome.runtime.lastError.message);
          }
        });
      }
      return;
    }

    const row = state.queue[state.index];
    addLog(`Initiating VIN: ${row.vin} (${state.index + 1}/${state.queue.length}) [Dynamic Speed: ${state.dynamicSpeed.siteHealth}]`, 'info');
    broadcastState();

    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    let targetTab = tabs.find(t => t.url && t.url.includes('connect.heromotocorp.biz'));
    if (!targetTab) {
      const allTabs = await chrome.tabs.query({});
      targetTab = allTabs.find(t => t.url && t.url.includes('connect.heromotocorp.biz'));
    }

    if (!targetTab) {
      addLog('Error: Siebel tab (Hero Connect) not found. Please navigate to Hero Connect.', 'error');
      state.status = 'PAUSED';
      saveState();
      broadcastState();
      return;
    }

    const targetTabId = targetTab.id;
    await waitTabComplete(targetTabId);

    const injected = await ensureContentScriptInjected(targetTabId);
    if (!injected) {
      state.status = 'PAUSED';
      saveState();
      broadcastState();
      return;
    }

    // Attach dynamic auto-tuned speed profile
    const payloadWithConfig = {
      ...row,
      speedProfile: state.dynamicSpeed.profile || 'balanced'
    };

    state.currentRowStartTime = Date.now();
    saveState();

    chrome.tabs.sendMessage(targetTabId, { type: 'PROCESS_ROW', payload: payloadWithConfig }, (response) => {
      if (chrome.runtime.lastError) {
        addLog('Error: Siebel page not responding. Retrying or check connection.', 'error');
        checkNetworkConnectivity();
      }
    });

    clearTimeout(processingTimeout);
    processingTimeout = setTimeout(() => {
      handleRowResult({
        vin: row.vin,
        status: 'Error',
        errorDetails: 'Timeout: Page did not complete in 55 seconds.'
      });
    }, 55000);
  });
}

function handleRowResult(payload) {
  loadState(() => {
    if (state.status !== 'RUNNING') return;

    const currentItem = state.queue[state.index];
    if (currentItem && currentItem.vin === payload.vin) {
      clearTimeout(processingTimeout);

      if (payload.status === 'Error' && state.settings.autoRetry && !currentItem._retryAttempted) {
        currentItem._retryAttempted = true;
        addLog(`Transient failure on VIN ${payload.vin} (${payload.errorDetails}). Auto-retrying once...`, 'warning');
        saveState();
        broadcastState();
        setTimeout(() => {
          processNext();
        }, 1000);
        return;
      }

      const durationSeconds = payload.duration !== undefined ? payload.duration : 
        (state.currentRowStartTime ? Math.round((Date.now() - state.currentRowStartTime) / 1000) : 10);

      // Adapt dynamic speed on website responsiveness!
      updateDynamicSpeed(durationSeconds);

      state.results.push({
        ...payload,
        battery_no: currentItem.battery_no || '',
        technician: currentItem.technician || '',
        status_requested: currentItem.status || 'Closed',
        timestamp: Date.now(),
        duration: durationSeconds
      });

      if (payload.status === 'Success') {
        state.consecutiveErrors = 0;
        addLog(`VIN ${payload.vin} processed successfully in ${durationSeconds}s.`, 'success');
      } else {
        state.consecutiveErrors = (state.consecutiveErrors || 0) + 1;
        addLog(`VIN ${payload.vin} failed (${durationSeconds}s): ${payload.errorDetails}`, 'error');

        if (state.settings.maxConsecutiveErrors > 0 && state.consecutiveErrors >= state.settings.maxConsecutiveErrors) {
          state.status = 'PAUSED';
          addLog(`Circuit Breaker: ${state.consecutiveErrors} consecutive errors reached. Pausing automation to protect queue.`, 'warning');
          state.index++;
          saveState();
          broadcastState();
          return;
        }
      }

      state.index++;
      saveState();

      // Dynamic inter-record throttle based on website performance!
      const gapMs = state.dynamicSpeed.interRecordDelay || 300;
      setTimeout(() => {
        processNext();
      }, gapMs);
    }
  });
}

// ═══════════════════════════════════════════════════════════════
// MESSAGE HANDLERS
// ═══════════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_STATE') {
    loadState(() => sendResponse(state));
    return true;
  }

  if (message.type === 'SET_QUEUE') {
    loadState(() => {
      // If there was a previous run with results, archive it before loading new queue
      if (state.results && state.results.length > 0) {
        archiveCurrentSession();
      }
      state.queue = message.queue;
      state.index = 0;
      state.results = [];
      state.consecutiveErrors = 0;
      addLog(`New queue loaded with ${message.queue.length} items. Ready.`, 'info');
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'START_QUEUE') {
    loadState(() => {
      if (message.queue && message.queue.length > 0 && state.queue.length === 0) {
        state.queue = message.queue;
        state.index = 0;
        state.results = [];
      }
      if (state.queue.length === 0) {
        addLog('Cannot start: No queue loaded.', 'warning');
        broadcastState();
        sendResponse({ success: false, reason: 'Empty queue' });
        return;
      }
      state.status = 'RUNNING';
      state.consecutiveErrors = 0;
      addLog('Automation started.', 'info');
      saveState();
      broadcastState();
      processNext();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'PAUSE_QUEUE') {
    loadState(() => {
      state.status = 'PAUSED';
      clearTimeout(processingTimeout);
      addLog('Automation paused by operator.', 'warning');
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'RESET_QUEUE') {
    loadState(() => {
      // Archive current session before wiping
      if (state.results && state.results.length > 0) {
        archiveCurrentSession();
      }
      state.status = 'IDLE';
      state.queue = [];
      state.index = 0;
      state.results = [];
      state.logs = [];
      state.consecutiveErrors = 0;
      clearTimeout(processingTimeout);
      addLog('Queue reset. Upload a new file or add records to start.', 'info');
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'NETWORK_STATUS_CHANGED') {
    if (message.online) {
      handleInternetRestored();
    } else {
      handleInternetLost();
    }
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'LOAD_SESSION_FAILED_RECORDS') {
    loadState(() => {
      const session = (state.sessions || []).find(s => s.id === message.sessionId);
      if (session) {
        const failedItems = session.results.filter(r => r.status === 'Error');
        if (failedItems.length > 0) {
          // If current queue had results from an active batch, archive them before overwriting
          if (state.results && state.results.length > 0 && state.results !== session.results) {
            archiveCurrentSession();
          }

          clearTimeout(processingTimeout);

          state.queue = failedItems.map(f => ({
            vin: f.vin,
            battery_no: f.battery_no || '',
            status: f.status_requested || 'Closed',
            technician: f.technician || ''
          }));
          state.index = 0;
          state.results = [];
          state.consecutiveErrors = 0;

          const shouldAutoStart = message.autoStart !== false;
          if (shouldAutoStart) {
            state.status = 'RUNNING';
            addLog(`Loaded ${state.queue.length} failed records from Session #${message.sessionId}. Retrying execution immediately...`, 'info');
            saveState();
            broadcastState();
            processNext();
          } else {
            state.status = 'IDLE';
            addLog(`Loaded ${state.queue.length} failed records from Session #${message.sessionId} into queue.`, 'info');
            saveState();
            broadcastState();
          }
        }
      }
      sendResponse({ success: true, count: session ? (session.results.filter(r => r.status === 'Error').length) : 0 });
    });
    return true;
  }

  if (message.type === 'DELETE_SESSION') {
    loadState(() => {
      state.sessions = (state.sessions || []).filter(s => s.id !== message.sessionId);
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'CLEAR_SESSIONS') {
    loadState(() => {
      state.sessions = [];
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'SKIP_CURRENT_ROW') {
    loadState(() => {
      if (state.index < state.queue.length) {
        const skipped = state.queue[state.index];
        state.results.push({
          vin: skipped.vin,
          status: 'Skipped',
          errorDetails: 'Skipped by user',
          timestamp: Date.now(),
          duration: 0
        });
        state.index++;
        addLog(`Skipped VIN: ${skipped.vin}`, 'warning');
        saveState();
        broadcastState();
        if (state.status === 'RUNNING') {
          processNext();
        }
      }
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'RETRY_ROW') {
    loadState(() => {
      const vinToRetry = message.vin;
      state.results = state.results.filter(r => r.vin !== vinToRetry);
      const qIndex = state.queue.findIndex(q => q.vin === vinToRetry);
      if (qIndex !== -1) {
        delete state.queue[qIndex]._retryAttempted;
        const [row] = state.queue.splice(qIndex, 1);
        state.queue.splice(state.index, 0, row);
        addLog(`VIN ${vinToRetry} queued for immediate retry.`, 'info');
        saveState();
        broadcastState();
        if (state.status !== 'RUNNING') {
          state.status = 'RUNNING';
          processNext();
        }
      }
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'UPDATE_RECORD') {
    loadState(() => {
      const { index, updatedRow } = message;
      if (state.queue[index]) {
        state.queue[index] = { ...state.queue[index], ...updatedRow };
        addLog(`Updated record #${index + 1}: ${updatedRow.vin}`, 'info');
        saveState();
        broadcastState();
      }
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'ADD_RECORD') {
    loadState(() => {
      state.queue.push(message.record);
      addLog(`Added record to queue: ${message.record.vin}`, 'info');
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'CLEAR_LOGS') {
    loadState(() => {
      state.logs = [];
      saveState();
      broadcastState();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'ROW_PROCESSED') {
    handleRowResult(message.payload);
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'LOG_MESSAGE') {
    addLog(message.message, message.level || 'info');
    broadcastState();
    sendResponse({ success: true });
    return true;
  }
});
