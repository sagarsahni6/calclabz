// Siebel PDI Automator Pro - Unified Single-Tab Controller
let keepAlivePort = null;
let currentQueue = [];
let currentResults = [];
let currentLogs = [];
let currentSessions = [];
let currentIndex = 0;
let currentStatus = 'IDLE';
let isOffline = false;
let dynamicSpeed = {
  profile: 'balanced',
  siteHealth: 'Standby',
  interRecordDelay: 350
};

let currentQueueFilter = 'all';
let currentQueueSearch = '';
let currentLogFilter = 'all';
let currentLogSearch = '';
let audioCtx = null;
let isSessionsCollapsed = false;
let lastCompletionShown = false;

// ═══════════════════════════════════════════════════════════════
// DOM ELEMENTS (Cached for performance)
// ═══════════════════════════════════════════════════════════════
const body = document.body;
const pulseIndicator = document.getElementById('pulse-indicator');
const statusBadge = document.getElementById('status-badge');
const speedPillLabel = document.getElementById('speed-pill-label');
const btnThemeToggle = document.getElementById('btn-theme-toggle');

// Offline Alert Banner
const offlineBanner = document.getElementById('offline-banner');
const btnCheckConnection = document.getElementById('btn-check-connection');

// Completion Banner
const completionBanner = document.getElementById('completion-banner');
const cbTitle = document.getElementById('cb-title');
const cbSub = document.getElementById('cb-sub');
const btnCbExport = document.getElementById('btn-cb-export');
const btnCbDismiss = document.getElementById('btn-cb-dismiss');

// Telemetry & Progress
const metricSpeed = document.getElementById('metric-speed');
const metricEtr = document.getElementById('metric-etr');
const metricRate = document.getElementById('metric-rate');
const metricProgressCount = document.getElementById('metric-progress-count');
const progressBarFill = document.getElementById('progress-bar-fill');
const progressPct = document.getElementById('progress-pct');

// Controls
const btnStart = document.getElementById('btn-start');
const btnPause = document.getElementById('btn-pause');
const btnSkip = document.getElementById('btn-skip');
const btnReset = document.getElementById('btn-reset');

// Upload & Quick Add
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const fileInfo = document.getElementById('file-info');
const linkDownloadTemplate = document.getElementById('link-download-template');
const btnQuickAddToggle = document.getElementById('btn-quick-add-toggle');
const quickAddSection = document.getElementById('quick-add-section');
const btnCloseQa = document.getElementById('btn-close-qa');
const qaVin = document.getElementById('qa-vin');
const qaTech = document.getElementById('qa-tech');
const qaBatt = document.getElementById('qa-batt');
const qaStatus = document.getElementById('qa-status');
const btnSubmitQuickAdd = document.getElementById('btn-submit-quick-add');

// Validation Banner
const validationBanner = document.getElementById('validation-banner');
const vbTitle = document.getElementById('vb-title');
const vbMsg = document.getElementById('vb-msg');
const btnVbAction = document.getElementById('btn-vb-action');

// Saved Sessions (Last 5)
const sessionsCountPill = document.getElementById('sessions-count-pill');
const btnToggleSessions = document.getElementById('btn-toggle-sessions');
const btnClearSessions = document.getElementById('btn-clear-sessions');
const sessionsContainer = document.getElementById('sessions-container');

// Active Queue & Table
const queueCountPill = document.getElementById('queue-count-pill');
const statSuccess = document.getElementById('stat-success');
const statError = document.getElementById('stat-error');
const statTotal = document.getElementById('stat-total');
const queueSearch = document.getElementById('queue-search');
const filterChips = document.querySelectorAll('.filter-chip');
const btnExportFullReport = document.getElementById('btn-export-full-report');
const btnExportFailedOnly = document.getElementById('btn-export-failed-only');
const queueTbody = document.getElementById('queue-tbody');

// Logs
const logSearch = document.getElementById('log-search');
const filterTabs = document.querySelectorAll('.filter-tab');
const logConsole = document.getElementById('log-console');
const btnCopyLogs = document.getElementById('btn-copy-logs');
const btnDownloadLogs = document.getElementById('btn-download-logs');
const btnClearLogs = document.getElementById('btn-clear-logs');

// Edit Modal
const editModal = document.getElementById('edit-modal');
const btnCloseEditModal = document.getElementById('btn-close-edit-modal');
const btnCancelEdit = document.getElementById('btn-cancel-edit');
const btnSaveEdit = document.getElementById('btn-save-edit');
const editRowIndex = document.getElementById('edit-row-index');
const editVin = document.getElementById('edit-vin');
const editTech = document.getElementById('edit-tech');
const editBatt = document.getElementById('edit-batt');
const editStatus = document.getElementById('edit-status');

// Confirmation Modal Elements (Zero native browser dialogs)
const confirmModal = document.getElementById('confirm-modal');
const confirmTitle = document.getElementById('confirm-title');
const confirmMessage = document.getElementById('confirm-message');
const btnCloseConfirmModal = document.getElementById('btn-close-confirm-modal');
const btnCancelConfirm = document.getElementById('btn-cancel-confirm');
const btnAcceptConfirm = document.getElementById('btn-accept-confirm');
const toastContainer = document.getElementById('toast-container');
let pendingConfirmCallback = null;

// ═══════════════════════════════════════════════════════════════
// TOAST NOTIFICATIONS (with click-to-dismiss and max stacking)
// ═══════════════════════════════════════════════════════════════
function showToast(message, type = 'info') {
  if (!toastContainer) return;

  // Limit toast stack to 3
  while (toastContainer.children.length >= 3) {
    toastContainer.firstChild.remove();
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const iconMap = {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    info: 'ℹ️'
  };

  toast.innerHTML = `
    <span class="toast-icon">${iconMap[type] || 'ℹ️'}</span>
    <span class="toast-msg">${escapeHtml(message)}</span>
  `;

  // Click to dismiss
  toast.addEventListener('click', () => {
    dismissToast(toast);
  });

  toastContainer.appendChild(toast);

  setTimeout(() => {
    dismissToast(toast);
  }, 3000);
}

function dismissToast(toast) {
  if (!toast || !toast.parentNode) return;
  toast.style.opacity = '0';
  toast.style.transform = 'translateY(8px)';
  setTimeout(() => {
    if (toast.parentNode) toast.remove();
  }, 250);
}

// ═══════════════════════════════════════════════════════════════
// IN-APP CONFIRM MODAL (Replaces native browser confirm())
// ═══════════════════════════════════════════════════════════════
function showConfirm(title, message, onConfirm) {
  if (!confirmModal) {
    if (typeof onConfirm === 'function') onConfirm();
    return;
  }
  confirmTitle.textContent = title;
  confirmMessage.textContent = message;
  pendingConfirmCallback = onConfirm;
  confirmModal.style.display = 'flex';

  // Focus the cancel button for keyboard accessibility
  setTimeout(() => btnCancelConfirm?.focus(), 100);
}

function closeConfirmModal() {
  if (confirmModal) confirmModal.style.display = 'none';
  pendingConfirmCallback = null;
}

// ═══════════════════════════════════════════════════════════════
// INITIALIZATION
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  connectKeepAlive();
  setupEventListeners();
  setupNetworkListeners();
  setupKeyboardShortcuts();
  requestState();
});

function connectKeepAlive() {
  try {
    keepAlivePort = chrome.runtime.connect({ name: 'siebel_pdi_keepalive' });
    keepAlivePort.onDisconnect.addListener(() => {
      setTimeout(connectKeepAlive, 1000);
    });
  } catch (e) { /* ignore */ }
}

function initTheme() {
  const savedTheme = localStorage.getItem('siebel_theme') || 'dark';
  if (savedTheme === 'light') {
    body.classList.remove('dark-theme');
    body.classList.add('light-theme');
  } else {
    body.classList.remove('light-theme');
    body.classList.add('dark-theme');
  }
}

function requestState() {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (chrome.runtime.lastError || !response) return;
    updateUI(response);
  });
}

// ═══════════════════════════════════════════════════════════════
// KEYBOARD SHORTCUTS & ACCESSIBILITY
// ═══════════════════════════════════════════════════════════════
function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Escape key closes modals
    if (e.key === 'Escape') {
      if (editModal.style.display === 'flex') {
        editModal.style.display = 'none';
        return;
      }
      if (confirmModal.style.display === 'flex') {
        closeConfirmModal();
        return;
      }
    }

    // Ctrl+T toggles theme
    if (e.ctrlKey && e.key === 't') {
      e.preventDefault();
      toggleTheme();
    }
  });
}

function toggleTheme() {
  const isLight = body.classList.toggle('light-theme');
  body.classList.toggle('dark-theme', !isLight);
  localStorage.setItem('siebel_theme', isLight ? 'light' : 'dark');
}

// ═══════════════════════════════════════════════════════════════
// NETWORK CONNECTIVITY LISTENERS (AUTO-PAUSE & RESUME)
// ═══════════════════════════════════════════════════════════════
function setupNetworkListeners() {
  window.addEventListener('online', () => {
    chrome.runtime.sendMessage({ type: 'NETWORK_STATUS_CHANGED', online: true });
  });

  window.addEventListener('offline', () => {
    chrome.runtime.sendMessage({ type: 'NETWORK_STATUS_CHANGED', online: false });
  });

  btnCheckConnection.addEventListener('click', async () => {
    btnCheckConnection.textContent = 'Testing...';
    btnCheckConnection.disabled = true;
    try {
      await fetch('https://connect.heromotocorp.biz/favicon.ico', { method: 'HEAD', cache: 'no-store' });
      chrome.runtime.sendMessage({ type: 'NETWORK_STATUS_CHANGED', online: true });
      showToast('Network connection verified!', 'success');
    } catch (e) {
      if (navigator.onLine) {
        chrome.runtime.sendMessage({ type: 'NETWORK_STATUS_CHANGED', online: true });
        showToast('Network connection verified!', 'success');
      } else {
        showToast('Still disconnected. Please check your internet connection.', 'error');
      }
    } finally {
      btnCheckConnection.textContent = 'Check Now';
      btnCheckConnection.disabled = false;
    }
  });
}

// ═══════════════════════════════════════════════════════════════
// EVENT LISTENERS SETUP
// ═══════════════════════════════════════════════════════════════
function setupEventListeners() {
  // In-app confirm modal wiring
  if (btnCloseConfirmModal) btnCloseConfirmModal.addEventListener('click', closeConfirmModal);
  if (btnCancelConfirm) btnCancelConfirm.addEventListener('click', closeConfirmModal);
  if (btnAcceptConfirm) {
    btnAcceptConfirm.addEventListener('click', () => {
      const cb = pendingConfirmCallback;
      closeConfirmModal();
      if (typeof cb === 'function') cb();
    });
  }

  // Theme Toggle
  btnThemeToggle.addEventListener('click', toggleTheme);

  // Completion Banner
  if (btnCbExport) {
    btnCbExport.addEventListener('click', () => {
      if (currentResults.length > 0) {
        exportResultsToCSV(currentResults, `pdi_audit_full_${Date.now()}.csv`);
      }
    });
  }
  if (btnCbDismiss) {
    btnCbDismiss.addEventListener('click', () => {
      completionBanner.style.display = 'none';
    });
  }

  // Drag & Drop
  dropZone.addEventListener('click', (e) => {
    if (e.target.id === 'link-download-template' || e.target.id === 'btn-quick-add-toggle') return;
    if (e.target.closest('#link-download-template') || e.target.closest('#btn-quick-add-toggle')) return;
    fileInput.click();
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleFile(e.target.files[0]);
    }
  });

  // Template Downloader
  linkDownloadTemplate.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const csvContent = 'vin,battery_no,status,technician\nMBLHA12ACGHC12225,BATT-883921,Closed,Amit Sharma\nMBLHA12ACGHC12226,BATT-883922,Closed,Ramesh Kumar\n';
    downloadBlob(csvContent, 'siebel_pdi_template.csv', 'text/csv;charset=utf-8;');
  });

  // Quick Add Toggle (CSS-driven collapse/expand)
  btnQuickAddToggle.addEventListener('click', (e) => {
    e.stopPropagation();
    const isCollapsed = quickAddSection.classList.contains('collapsed');
    if (isCollapsed) {
      quickAddSection.classList.remove('collapsed');
      quickAddSection.style.maxHeight = quickAddSection.scrollHeight + 'px';
      quickAddSection.style.opacity = '1';
      setTimeout(() => qaVin?.focus(), 200);
    } else {
      quickAddSection.style.maxHeight = '0';
      quickAddSection.style.opacity = '0';
      setTimeout(() => quickAddSection.classList.add('collapsed'), 350);
    }
  });

  btnCloseQa.addEventListener('click', () => {
    quickAddSection.style.maxHeight = '0';
    quickAddSection.style.opacity = '0';
    setTimeout(() => quickAddSection.classList.add('collapsed'), 350);
  });

  btnSubmitQuickAdd.addEventListener('click', () => {
    const vin = qaVin.value.trim().toUpperCase();
    if (!vin) {
      showToast('Please enter a VIN.', 'warning');
      qaVin.focus();
      return;
    }

    if (vin.length !== 17) {
      showToast(`VIN should be 17 characters (currently ${vin.length}).`, 'warning');
    }

    const record = {
      vin,
      technician: qaTech.value.trim(),
      battery_no: qaBatt.value.trim(),
      status: qaStatus.value
    };

    chrome.runtime.sendMessage({ type: 'ADD_RECORD', record }, () => {
      qaVin.value = '';
      qaTech.value = '';
      qaBatt.value = '';
      showToast(`Record ${vin} added to queue.`, 'success');
      requestState();
    });
  });

  // Submit on Enter in Quick Add VIN field
  qaVin.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      btnSubmitQuickAdd.click();
    }
  });

  // Execution Controls
  btnStart.addEventListener('click', () => {
    completionBanner.style.display = 'none';
    lastCompletionShown = false;
    chrome.runtime.sendMessage({ type: 'START_QUEUE', queue: currentQueue });
  });

  btnPause.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'PAUSE_QUEUE' });
  });

  btnSkip.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'SKIP_CURRENT_ROW' });
    showToast('Skipping current record...', 'warning');
  });

  btnReset.addEventListener('click', () => {
    showConfirm('Reset Queue', 'Are you sure you want to reset the queue? Completed records will be saved to session history.', () => {
      completionBanner.style.display = 'none';
      lastCompletionShown = false;
      chrome.runtime.sendMessage({ type: 'RESET_QUEUE' });
      showToast('Queue reset. Archived to history.', 'info');
    });
  });

  // Saved Sessions Controls
  btnToggleSessions.addEventListener('click', () => {
    isSessionsCollapsed = !isSessionsCollapsed;
    if (isSessionsCollapsed) {
      sessionsContainer.classList.add('collapsed');
    } else {
      sessionsContainer.classList.remove('collapsed');
    }
    btnToggleSessions.textContent = isSessionsCollapsed ? 'Expand' : 'Collapse';
  });

  btnClearSessions.addEventListener('click', () => {
    showConfirm('Clear History', 'Are you sure you want to clear all archived session history?', () => {
      chrome.runtime.sendMessage({ type: 'CLEAR_SESSIONS' });
      showToast('Session history cleared.', 'info');
    });
  });

  // Queue Toolbar: Filter Chips & Search
  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentQueueFilter = chip.getAttribute('data-qfilter');
      renderQueueTable();
    });
  });

  queueSearch.addEventListener('input', (e) => {
    currentQueueSearch = e.target.value.trim().toLowerCase();
    renderQueueTable();
  });

  // Export Full Report
  btnExportFullReport.addEventListener('click', () => {
    if (!currentResults || currentResults.length === 0) return;
    exportResultsToCSV(currentResults, `pdi_audit_full_${Date.now()}.csv`);
  });

  // Export Failed Only
  btnExportFailedOnly.addEventListener('click', () => {
    const failed = currentResults.filter(r => r.status === 'Error');
    if (failed.length === 0) {
      showToast('No failed records in current run.', 'info');
      return;
    }
    let csv = 'vin,battery_no,status,technician\n';
    failed.forEach(r => {
      csv += `"${csvSafe(r.vin)}","${csvSafe(r.battery_no || '')}","${csvSafe(r.status_requested || 'Closed')}","${csvSafe(r.technician || '')}"\n`;
    });
    downloadBlob(csv, `pdi_failed_reupload_${Date.now()}.csv`, 'text/csv;charset=utf-8;');
  });

  // Logs Toolbar
  logSearch.addEventListener('input', (e) => {
    currentLogSearch = e.target.value.toLowerCase();
    renderLogs();
  });

  filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      filterTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentLogFilter = tab.getAttribute('data-filter');
      renderLogs();
    });
  });

  btnCopyLogs.addEventListener('click', () => {
    const text = currentLogs.map(l => `[${new Date(l.timestamp).toLocaleTimeString()}] [${l.level.toUpperCase()}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text).then(() => showToast('Logs copied to clipboard!', 'success'));
  });

  btnDownloadLogs.addEventListener('click', () => {
    const text = currentLogs.map(l => `[${new Date(l.timestamp).toLocaleTimeString()}] [${l.level.toUpperCase()}] ${l.message}`).join('\n');
    downloadBlob(text, `siebel_pdi_logs_${Date.now()}.txt`, 'text/plain;charset=utf-8;');
  });

  btnClearLogs.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'CLEAR_LOGS' });
  });

  // Edit Modal Listeners
  btnCloseEditModal.addEventListener('click', () => editModal.style.display = 'none');
  btnCancelEdit.addEventListener('click', () => editModal.style.display = 'none');

  btnSaveEdit.addEventListener('click', () => {
    const idx = parseInt(editRowIndex.value);
    const updatedRow = {
      vin: editVin.value.trim().toUpperCase(),
      technician: editTech.value.trim(),
      battery_no: editBatt.value.trim(),
      status: editStatus.value
    };

    if (!updatedRow.vin) {
      showToast('VIN cannot be empty.', 'warning');
      editVin.focus();
      return;
    }

    chrome.runtime.sendMessage({
      type: 'UPDATE_RECORD',
      index: idx,
      updatedRow
    }, () => {
      editModal.style.display = 'none';
      showToast(`Record #${idx + 1} updated.`, 'success');
      requestState();
    });
  });

  // Save on Enter in edit modal
  editVin.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') btnSaveEdit.click();
  });
}

// ═══════════════════════════════════════════════════════════════
// FILE PARSING & PRE-FLIGHT VALIDATION
// ═══════════════════════════════════════════════════════════════
function handleFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const text = e.target.result;
      let records = [];
      if (file.name.endsWith('.json')) {
        records = JSON.parse(text);
      } else {
        records = parseCSV(text);
      }

      if (records.length === 0) {
        throw new Error('No valid records found in file.');
      }

      // Mark drop zone as loaded
      dropZone.classList.add('loaded');
      validateAndLoadQueue(records, file.name);
    } catch (err) {
      fileInfo.textContent = `Error: ${err.message}`;
      fileInfo.style.color = 'var(--danger)';
      dropZone.classList.remove('loaded');
      btnStart.disabled = true;
      showToast(`File error: ${err.message}`, 'error');
    }
  };
  reader.readAsText(file);
}

/**
 * Robust CSV parser that handles quoted fields with commas and newlines.
 */
function parseCSV(text) {
  const lines = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '"') {
      if (inQuotes && text[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === '\n' && !inQuotes) {
      const trimmed = current.replace(/\r$/, '').trim();
      if (trimmed.length > 0) lines.push(trimmed);
      current = '';
    } else {
      current += ch;
    }
  }
  const finalTrimmed = current.replace(/\r$/, '').trim();
  if (finalTrimmed.length > 0) lines.push(finalTrimmed);

  if (lines.length < 2) return [];

  const splitCSVLine = (line) => {
    const result = [];
    let field = '';
    let quoted = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (quoted && line[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          quoted = !quoted;
        }
      } else if (c === ',' && !quoted) {
        result.push(field.trim());
        field = '';
      } else {
        field += c;
      }
    }
    result.push(field.trim());
    return result;
  };

  const headers = splitCSVLine(lines[0]).map(h => h.toLowerCase().replace(/^["']|["']$/g, ''));
  const vinIndex = headers.indexOf('vin');
  const batteryIndex = headers.findIndex(h => h.includes('battery') || h.includes('serial'));
  const statusIndex = headers.findIndex(h => h.includes('status') || h.includes('pdi'));
  const techIndex = headers.findIndex(h => h.includes('tech') || h.includes('mechanic'));

  if (vinIndex === -1) {
    throw new Error('CSV must contain a "vin" column header.');
  }

  const records = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = splitCSVLine(lines[i]).map(c => c.replace(/^["']|["']$/g, ''));
    if (cols.length <= vinIndex || !cols[vinIndex]) continue;

    records.push({
      vin: cols[vinIndex].toUpperCase(),
      battery_no: batteryIndex !== -1 ? cols[batteryIndex] : '',
      status: statusIndex !== -1 ? (cols[statusIndex] || 'Closed') : 'Closed',
      technician: techIndex !== -1 ? cols[techIndex] : ''
    });
  }

  return records;
}

function validateAndLoadQueue(records, filename) {
  const vinCounts = new Map();
  const duplicates = [];
  const abnormalLength = [];

  records.forEach((r) => {
    const v = r.vin;
    vinCounts.set(v, (vinCounts.get(v) || 0) + 1);
    if (vinCounts.get(v) === 2) duplicates.push(v);
    if (v.length !== 17) abnormalLength.push(v);
  });

  if (duplicates.length > 0) {
    validationBanner.style.display = 'flex';
    vbTitle.textContent = `${duplicates.length} Duplicate VINs Detected`;
    vbMsg.textContent = `Found duplicates like "${duplicates[0]}". Click Deduplicate to clean.`;
    btnVbAction.textContent = 'Deduplicate';
    btnVbAction.onclick = () => {
      const seen = new Set();
      const uniqueRecords = records.filter(r => {
        if (seen.has(r.vin)) return false;
        seen.add(r.vin);
        return true;
      });
      validationBanner.style.display = 'none';
      commitQueue(uniqueRecords, filename);
    };
  } else if (abnormalLength.length > 0) {
    validationBanner.style.display = 'flex';
    vbTitle.textContent = `Non-standard VIN lengths (${abnormalLength.length})`;
    vbMsg.textContent = `Some VINs do not have 17 chars (e.g. "${abnormalLength[0]}").`;
    btnVbAction.textContent = 'Dismiss';
    btnVbAction.onclick = () => validationBanner.style.display = 'none';
  } else {
    validationBanner.style.display = 'none';
  }

  commitQueue(records, filename);
}

function commitQueue(records, filename) {
  currentQueue = records;
  fileInfo.textContent = `${filename} — ${records.length} records loaded ✓`;
  fileInfo.style.color = 'var(--success)';
  btnStart.disabled = false;
  btnReset.disabled = false;

  // Reset completion state
  completionBanner.style.display = 'none';
  lastCompletionShown = false;

  chrome.runtime.sendMessage({ type: 'SET_QUEUE', queue: records });
  showToast(`${records.length} records loaded from ${filename}`, 'success');
}

// ═══════════════════════════════════════════════════════════════
// UI STATE SYNCHRONIZATION
// ═══════════════════════════════════════════════════════════════
function updateUI(state) {
  const { status, queue, index, results, logs, sessions, dynamicSpeed: dSpeed } = state;
  currentStatus = status || 'IDLE';
  currentQueue = queue || [];
  currentIndex = index || 0;
  currentResults = results || [];
  currentLogs = logs || [];
  currentSessions = sessions || [];
  isOffline = !!state.isOffline;

  if (dSpeed) {
    dynamicSpeed = { ...dynamicSpeed, ...dSpeed };
  }

  const total = currentQueue.length;
  const successCount = currentResults.filter(r => r.status === 'Success').length;
  const errorCount = currentResults.filter(r => r.status === 'Error').length;
  const isComplete = total > 0 && currentIndex >= total && currentStatus === 'IDLE';

  // 1. Dynamic Speed Pill Update
  if (dynamicSpeed.siteHealth) {
    speedPillLabel.textContent = `Auto-Speed: ${dynamicSpeed.siteHealth}`;
  } else {
    speedPillLabel.textContent = 'Auto-Speed: Active';
  }

  // 2. Offline Banner & Indicator
  if (isOffline || !navigator.onLine) {
    offlineBanner.style.display = 'flex';
    statusBadge.textContent = 'OFFLINE';
    statusBadge.className = 'badge offline';
    pulseIndicator.className = 'pulse-indicator offline';
    completionBanner.style.display = 'none';
  } else {
    offlineBanner.style.display = 'none';

    if (isComplete) {
      statusBadge.textContent = 'COMPLETE';
      statusBadge.className = 'badge complete';
      pulseIndicator.className = 'pulse-indicator complete';
    } else {
      statusBadge.textContent = currentStatus;
      statusBadge.className = 'badge';
      pulseIndicator.className = 'pulse-indicator';

      if (currentStatus === 'RUNNING') {
        statusBadge.classList.add('running');
        pulseIndicator.classList.add('running');
      } else if (currentStatus === 'PAUSED') {
        statusBadge.classList.add('paused');
        pulseIndicator.classList.add('paused');
      }
    }
  }

  // 3. Stats & Telemetry
  statTotal.textContent = total;
  statSuccess.textContent = successCount;
  statError.textContent = errorCount;
  metricProgressCount.textContent = `${currentIndex} / ${total}`;

  // Progress Bar
  const pct = total > 0 ? Math.round((currentIndex / total) * 100) : 0;
  progressBarFill.style.width = `${pct}%`;
  progressPct.textContent = `${pct}%`;

  if (isComplete) {
    progressBarFill.classList.add('complete');
    progressPct.className = 'progress-pct complete';
  } else if (currentStatus === 'RUNNING') {
    progressBarFill.classList.remove('complete');
    progressPct.className = 'progress-pct active';
  } else {
    progressBarFill.classList.remove('complete');
    progressPct.className = 'progress-pct';
  }

  // Telemetry: Speed, ETR, Rate
  const validDurations = currentResults.filter(r => r.duration && r.duration > 0);
  let avgSec = 0;
  if (validDurations.length > 0) {
    const totalSec = validDurations.reduce((sum, r) => sum + r.duration, 0);
    avgSec = Math.round((totalSec / validDurations.length) * 10) / 10;
    metricSpeed.textContent = `${avgSec}s / VIN`;

    const vPerHour = Math.round(3600 / avgSec);
    metricRate.textContent = `${vPerHour} / hr`;
  } else {
    metricSpeed.textContent = dynamicSpeed.recentDurations && dynamicSpeed.recentDurations.length > 0
      ? `${Math.round((dynamicSpeed.recentDurations.reduce((a,b)=>a+b,0)/dynamicSpeed.recentDurations.length)*10)/10}s`
      : '--';
    metricRate.textContent = '--';
  }

  if (currentStatus === 'RUNNING' && avgSec > 0 && currentIndex < total) {
    const remSec = (total - currentIndex) * avgSec;
    const mins = Math.floor(remSec / 60);
    const secs = Math.round(remSec % 60);
    metricEtr.textContent = `${mins}m ${secs}s`;
  } else {
    metricEtr.textContent = '--';
  }

  // Button States
  if (isOffline) {
    btnStart.disabled = true;
    btnPause.disabled = true;
    btnSkip.disabled = true;
    btnReset.disabled = false;
  } else if (currentStatus === 'RUNNING') {
    btnStart.disabled = true;
    btnPause.disabled = false;
    btnSkip.disabled = false;
    btnReset.disabled = false;
    dropZone.style.pointerEvents = 'none';
    dropZone.style.opacity = '0.5';
  } else if (currentStatus === 'PAUSED') {
    btnStart.disabled = false;
    btnPause.disabled = true;
    btnSkip.disabled = false;
    btnReset.disabled = false;
    dropZone.style.pointerEvents = 'none';
    dropZone.style.opacity = '0.5';
  } else { // IDLE
    btnStart.disabled = currentQueue.length === 0;
    btnPause.disabled = true;
    btnSkip.disabled = true;
    btnReset.disabled = total === 0 && currentResults.length === 0;
    dropZone.style.pointerEvents = 'auto';
    dropZone.style.opacity = '1';
  }

  btnExportFullReport.disabled = currentResults.length === 0;
  btnExportFailedOnly.disabled = errorCount === 0;

  // Completion Banner & Sound
  if (isComplete && !lastCompletionShown) {
    lastCompletionShown = true;

    // Show completion banner
    cbTitle.textContent = errorCount === 0 ? '🎉 Batch Complete!' : '⚡ Batch Finished';
    cbSub.textContent = `${successCount} success, ${errorCount} failed out of ${total} total records.`;
    completionBanner.style.display = 'flex';

    playCompletionChime();
  } else if (!isComplete) {
    lastCompletionShown = false;
  }

  renderSavedSessions();
  renderQueueTable();
  renderLogs();
}

// ═══════════════════════════════════════════════════════════════
// RENDER SAVED SESSIONS (LAST 5 SESSIONS)
// ═══════════════════════════════════════════════════════════════
function renderSavedSessions() {
  sessionsCountPill.textContent = `${currentSessions.length}/5`;
  sessionsContainer.innerHTML = '';

  if (currentSessions.length === 0) {
    sessionsContainer.innerHTML = '<div class="empty-sessions-notice"><span class="empty-icon">📋</span>No completed sessions yet. Finished runs appear here automatically.</div>';
    return;
  }

  // Display sessions in reverse chronological order (newest on top)
  const reversed = [...currentSessions].reverse();
  reversed.forEach((sess, idx) => {
    const card = document.createElement('div');
    card.className = 'session-card';

    const sessionNum = currentSessions.length - idx;
    const timeFormatted = new Date(sess.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateFormatted = new Date(sess.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' });
    const successRate = sess.total > 0 ? Math.round((sess.successCount / sess.total) * 100) : 0;
    const hasErrors = sess.errorCount > 0;

    card.innerHTML = `
      <div class="sc-info">
        <div class="sc-title">
          <span>Session #${sessionNum}</span>
          <span class="sc-date">${dateFormatted}, ${timeFormatted}</span>
        </div>
        <div class="sc-badges">
          <span class="sc-chip ok">✅ ${sess.successCount} OK</span>
          ${sess.errorCount > 0 ? `<span class="sc-chip err">❌ ${sess.errorCount} Fail</span>` : ''}
          ${sess.avgSpeed > 0 ? `<span class="sc-chip speed">⚡ ${sess.avgSpeed}s avg</span>` : ''}
        </div>
        <div class="sc-progress-bar">
          <div class="sc-progress-fill ${hasErrors ? 'has-errors' : ''}" style="width: ${successRate}%"></div>
        </div>
      </div>
      <div class="sc-actions">
        ${sess.errorCount > 0 ? `
          <button class="btn btn-xs btn-outline-danger btn-reload-failed" data-id="${sess.id}" title="Reload failed VINs from this session into queue for retry">
            🔄 Retry
          </button>
        ` : ''}
        <button class="btn btn-xs btn-outline-info btn-export-session" data-id="${sess.id}" title="Export CSV report for this session">
          📥
        </button>
        <button class="row-action-btn btn-delete-session" data-id="${sess.id}" title="Remove session">
          &times;
        </button>
      </div>
    `;

    sessionsContainer.appendChild(card);
  });

  // Attach Session Action Listeners
  sessionsContainer.querySelectorAll('.btn-export-session').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.getAttribute('data-id'));
      const session = currentSessions.find(s => s.id === id);
      if (session && session.results) {
        exportResultsToCSV(session.results, `pdi_session_${id}.csv`);
      }
    });
  });

  sessionsContainer.querySelectorAll('.btn-reload-failed').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = parseInt(btn.getAttribute('data-id'));
      const session = currentSessions.find(s => s.id === id);
      const failCount = session ? session.errorCount : '';

      btn.textContent = '⏳ Loading...';
      btn.disabled = true;

      chrome.runtime.sendMessage({
        type: 'LOAD_SESSION_FAILED_RECORDS',
        sessionId: id,
        autoStart: true
      }, () => {
        showToast(`Loaded ${failCount || ''} failed records. Automation started!`, 'success');
        requestState();
      });
    });
  });

  sessionsContainer.querySelectorAll('.btn-delete-session').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = parseInt(btn.getAttribute('data-id'));
      chrome.runtime.sendMessage({ type: 'DELETE_SESSION', sessionId: id }, () => {
        showToast('Session removed from history.', 'info');
      });
    });
  });
}

// ═══════════════════════════════════════════════════════════════
// RENDER UNIFIED ACTIVE QUEUE & AUDIT TABLE
// ═══════════════════════════════════════════════════════════════
function renderQueueTable() {
  queueCountPill.textContent = `${currentQueue.length} items`;
  queueTbody.innerHTML = '';

  if (currentQueue.length === 0) {
    queueTbody.innerHTML = '<tr><td colspan="5" class="empty-state"><span class="empty-state-icon">📂</span>No records loaded. Upload CSV or add a VIN above.</td></tr>';
    return;
  }

  const items = currentQueue.map((item, idx) => {
    let rowStatus = 'pending';
    let duration = null;
    let errorDetails = '';

    if (idx === currentIndex && currentStatus === 'RUNNING') {
      rowStatus = 'running';
    } else {
      const res = currentResults.find(r => r.vin === item.vin);
      if (res) {
        rowStatus = res.status === 'Success' ? 'success' : (res.status === 'Skipped' ? 'skipped' : 'error');
        duration = res.duration;
        errorDetails = res.errorDetails || '';
      }
    }

    return {
      ...item,
      originalIndex: idx,
      rowStatus,
      duration,
      errorDetails
    };
  });

  // Apply filters
  const filtered = items.filter(item => {
    // 1. Filter by chip
    if (currentQueueFilter === 'pending' && item.rowStatus !== 'pending' && item.rowStatus !== 'running') return false;
    if (currentQueueFilter === 'success' && item.rowStatus !== 'success') return false;
    if (currentQueueFilter === 'error' && item.rowStatus !== 'error') return false;

    // 2. Filter by search text
    if (currentQueueSearch) {
      const term = currentQueueSearch;
      return item.vin.toLowerCase().includes(term) ||
             (item.technician && item.technician.toLowerCase().includes(term));
    }
    return true;
  });

  if (filtered.length === 0) {
    queueTbody.innerHTML = '<tr><td colspan="5" class="empty-state"><span class="empty-state-icon">🔍</span>No records match the active filter or search.</td></tr>';
    return;
  }

  filtered.forEach(item => {
    const tr = document.createElement('tr');
    const idx = item.originalIndex;
    if (item.rowStatus === 'running') {
      tr.classList.add('active-row');
    }

    let statusDisplay = item.rowStatus;
    if (item.duration) {
      statusDisplay += ` (${item.duration}s)`;
    }

    tr.innerHTML = `
      <td style="color: var(--text-sub); font-size: 0.65rem;">${idx + 1}</td>
      <td>
        <span class="cell-vin" data-index="${idx}" title="Click to edit">${escapeHtml(item.vin)}</span>
        ${item.errorDetails ? `<div style="font-size: 0.58rem; color: var(--danger); max-width: 130px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escapeHtml(item.errorDetails)}">${escapeHtml(item.errorDetails)}</div>` : ''}
      </td>
      <td style="color: var(--text-muted); font-size: 0.65rem;">${escapeHtml(item.technician || '—')}</td>
      <td><span class="status-chip ${item.rowStatus}">${escapeHtml(statusDisplay)}</span></td>
      <td style="text-align: center;">
        ${item.rowStatus === 'error' ? `
          <button class="row-action-btn btn-retry-single" data-vin="${escapeHtml(item.vin)}" title="Retry VIN immediately" style="color: var(--warning);">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path></svg>
          </button>
        ` : `
          <button class="row-action-btn btn-edit-row" data-index="${idx}" title="Edit Record">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
          </button>
        `}
      </td>
    `;
    queueTbody.appendChild(tr);
  });

  // Attach click handlers
  queueTbody.querySelectorAll('.cell-vin, .btn-edit-row').forEach(el => {
    el.addEventListener('click', () => {
      const idx = parseInt(el.getAttribute('data-index'));
      openEditModal(idx);
    });
  });

  queueTbody.querySelectorAll('.btn-retry-single').forEach(btn => {
    btn.addEventListener('click', () => {
      const vin = btn.getAttribute('data-vin');
      chrome.runtime.sendMessage({ type: 'RETRY_ROW', vin });
      showToast(`Retrying ${vin}...`, 'info');
    });
  });
}

function openEditModal(idx) {
  const row = currentQueue[idx];
  if (!row) return;

  editRowIndex.value = idx;
  editVin.value = row.vin || '';
  editTech.value = row.technician || '';
  editBatt.value = row.battery_no || '';
  editStatus.value = row.status || 'Closed';
  editModal.style.display = 'flex';

  // Focus VIN field after animation
  setTimeout(() => editVin?.focus(), 150);
}

// ═══════════════════════════════════════════════════════════════
// RENDER LOGS CONSOLE
// ═══════════════════════════════════════════════════════════════
function renderLogs() {
  logConsole.innerHTML = '';

  const filtered = currentLogs.filter(log => {
    if (currentLogFilter !== 'all' && log.level !== currentLogFilter) return false;
    if (currentLogSearch && !log.message.toLowerCase().includes(currentLogSearch)) return false;
    return true;
  });

  if (filtered.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'log-item info';
    empty.style.fontStyle = 'italic';
    empty.textContent = 'No matching log entries.';
    logConsole.appendChild(empty);
    return;
  }

  filtered.forEach(log => {
    const item = document.createElement('div');
    item.className = `log-item ${log.level}`;
    const time = new Date(log.timestamp).toLocaleTimeString();
    item.textContent = `[${time}] ${log.message}`;
    logConsole.appendChild(item);
  });

  logConsole.scrollTop = logConsole.scrollHeight;
}

// ═══════════════════════════════════════════════════════════════
// CSV EXPORT HELPER (XSS-safe, handles commas in fields)
// ═══════════════════════════════════════════════════════════════
function exportResultsToCSV(results, filename) {
  if (!results || results.length === 0) return;
  let csv = 'VIN,Requested Status,Battery Serial,Result Status,Error Details,Duration (Seconds),Processed At\n';
  results.forEach(r => {
    const timeStr = new Date(r.timestamp || Date.now()).toLocaleString();
    csv += `"${csvSafe(r.vin)}","${csvSafe(r.status_requested || 'Closed')}","${csvSafe(r.battery_no || '')}","${csvSafe(r.status)}","${csvSafe(r.errorDetails || '')}","${r.duration || ''}","${timeStr}"\n`;
  });
  downloadBlob(csv, filename, 'text/csv;charset=utf-8;');
}

// ═══════════════════════════════════════════════════════════════
// AUDIO CHIME (SYNTHESIZED WEB AUDIO API - OFFLINE SAFE)
// ═══════════════════════════════════════════════════════════════
function playCompletionChime() {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    if (!audioCtx) audioCtx = new AudioContext();

    const now = audioCtx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.1);
      gain.gain.setValueAtTime(0.12, now + idx * 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.4);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now + idx * 0.1);
      osc.stop(now + idx * 0.1 + 0.45);
    });
  } catch (e) { /* ignore */ }
}

// ═══════════════════════════════════════════════════════════════
// UTILITY HELPERS
// ═══════════════════════════════════════════════════════════════

/** Safely escape CSV field values (double-quote escaping) */
function csvSafe(str) {
  if (str == null) return '';
  return String(str).replace(/"/g, '""');
}

/** Escape HTML to prevent XSS in innerHTML */
function escapeHtml(str) {
  if (str == null) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/** Download file with delayed URL revoke to prevent race condition */
function downloadBlob(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Delay revoke to ensure download initiates (fixes race condition on some browsers)
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// State update listener from background service worker
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'STATE_UPDATED') {
    updateUI(message.state);
  }
});
