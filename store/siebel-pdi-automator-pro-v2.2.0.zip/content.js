/**
 * Siebel PDI Automator Pro — Content Script (Bridge)
 * ───────────────────────────────────────────────────
 * This content script acts as a message bridge between:
 *   - The extension background service worker (chrome.runtime)
 *   - The page-context automation engine (inject.js via window.postMessage)
 *
 * It also injects inject.js into the page DOM so the automation engine
 * can access the Oracle Siebel CRM JavaScript API (window.SiebelApp).
 *
 * NO user data is collected or transmitted externally.
 */

// Inject the inject.js script into the webpage DOM context
function injectScript() {
  try {
    const existing = document.getElementById('siebel-pdi-injected-engine');
    if (existing) existing.remove();

    const script = document.createElement('script');
    script.id = 'siebel-pdi-injected-engine';
    script.src = chrome.runtime.getURL('inject.js');
    script.onload = function() {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
    console.log('[Siebel Automator Pro] inject.js successfully injected.');
  } catch (err) {
    console.error('[Siebel Automator Pro] Injection failed:', err);
  }
}

injectScript();

// Message listener from extension background worker
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PING') {
    sendResponse({ type: 'PONG', active: true });
    return true;
  }

  if (message.type === 'REINJECT') {
    injectScript();
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'PROCESS_ROW') {
    window.postMessage({
      type: 'SIEBEL_PROCESS_ROW',
      payload: message.payload
    }, '*');
    sendResponse({ success: true });
    return true;
  }
});

// Receive message from DOM Context (inject.js) -> Relay to Background Script
window.addEventListener('message', (event) => {
  if (event.source !== window || !event.data) return;

  if (event.data.type === 'SIEBEL_LOG_MESSAGE') {
    const { message: logMsg, level } = event.data;
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage({ type: 'LOG_MESSAGE', message: logMsg, level });
      }
    } catch (e) { /* context invalidated */ }
  }

  if (event.data.type === 'PDI_RECORD_PROCESSED') {
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage({
          type: 'ROW_PROCESSED',
          payload: event.data.payload
        });
      }
    } catch (err) {
      console.warn('[Siebel Automator Pro] Extension context invalidated. Please refresh the page if continuing automation.');
    }
  }
});

// Network connectivity listeners to pause on disconnect and resume on connect
window.addEventListener('online', () => {
  try {
    if (chrome.runtime && chrome.runtime.id) {
      chrome.runtime.sendMessage({ type: 'NETWORK_STATUS_CHANGED', online: true });
    }
  } catch (e) {}
});

window.addEventListener('offline', () => {
  try {
    if (chrome.runtime && chrome.runtime.id) {
      chrome.runtime.sendMessage({ type: 'NETWORK_STATUS_CHANGED', online: false });
    }
  } catch (e) {}
});

